document.addEventListener('DOMContentLoaded', function() {
    const replyButton = document.getElementById('reply-button');
    const footerButtons = document.getElementById('footer-buttons');
    const replySection = document.getElementById('reply-section');
    const saveButton = document.getElementById('save-button');
    const cancelButton = document.getElementById('cancel-button');
    const postDetails = document.getElementById('postDetails');
    const responseContent = document.getElementById('responseContent');
    const footerBtns = document.getElementById('footerButtons');

    // 답변 여부 확인: 답변이 없으면 수정/삭제 버튼 숨기기
    if (responseContent.innerText.trim() === "") {
        footerBtns.style.display = 'none'; // 답변이 없으면 수정/삭제 버튼 숨기기
    } else {
        footerBtns.style.display = 'block'; // 답변이 있으면 수정/삭제 버튼 보이기
    }

    // 답변하기 버튼 클릭 시 동작
    replyButton.addEventListener('click', function() {
        footerButtons.style.display = 'none'; // 기존 버튼 숨김
        replySection.style.display = 'block'; // 답변 섹션 보이기
    });

    // 답변 저장 버튼 클릭 시 동작
    saveButton.addEventListener('click', function() {
        const replyText = document.getElementById('replyText').value;
        if (replyText.trim() !== "") {
            responseContent.innerText = replyText; // 답변 내용 설정
            replySection.style.display = 'none'; // 답변 섹션 숨김
            postDetails.style.display = 'block'; // 답변 내용 표시
            footerBtns.style.display = 'block'; // 수정 및 삭제 버튼 보이기
            replyButton.style.display = 'none'; // 답변하기 버튼 숨기기
        } else {
            alert('답변 내용을 입력해 주세요.');
        }
    });

    // 답변 취소 버튼 클릭 시 동작
    cancelButton.addEventListener('click', function() {
        replySection.style.display = 'none'; // 답변 섹션 숨김
        footerButtons.style.display = 'flex'; // 기존 버튼 보이기
    });

    // 수정하기 버튼 클릭 시 동작
    const editResponseButton = document.getElementById('editResponseButton');
    const saveResponseButton = document.getElementById('saveResponseButton');
    const cancelEditButton = document.getElementById('cancelButton');
    const editResponseSection = document.getElementById('editResponseSection');
    
    editResponseButton.addEventListener('click', function() {
        const currentContent = responseContent.innerText;
        document.getElementById('editResponseText').value = currentContent;
        postDetails.style.display = 'none';
        editResponseSection.style.display = 'block';
    });

    // 수정된 답변 저장 버튼 클릭 시 동작
    saveResponseButton.addEventListener('click', function() {
        const updatedContent = document.getElementById('editResponseText').value;
        if (updatedContent.trim() !== "") {
            responseContent.innerText = updatedContent;
            editResponseSection.style.display = 'none';
            postDetails.style.display = 'block';
        } else {
            alert('수정된 답변 내용을 입력해 주세요.');
        }
    });

    // 답변 수정 취소 버튼 클릭 시 동작
    cancelEditButton.addEventListener('click', function() {
        editResponseSection.style.display = 'none';
        postDetails.style.display = 'block';
    });
});

// 답변 삭제 로직
function deleteResponse() {
    const userConfirmed = confirm('정말 삭제하시겠습니까?');

    if (userConfirmed) {
        alert('답변이 삭제되었습니다.');
        document.getElementById('postDetails').style.display = 'none'; // 답변 내용 숨기기
        document.getElementById('footerButtons').style.display = 'none'; // 수정/삭제 버튼 숨기기
        document.getElementById('reply-button').style.display = 'block'; // 다시 답변하기 버튼 보이기
        document.getElementById('responseContent').innerText = ""; // 답변 내용 삭제
    } else {
        alert('삭제가 취소되었습니다.');
    }
}
