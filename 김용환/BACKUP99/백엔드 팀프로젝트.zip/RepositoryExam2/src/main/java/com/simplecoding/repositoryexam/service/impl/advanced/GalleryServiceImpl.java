/**
 * 
 */
package com.simplecoding.repositoryexam.service.impl.advanced;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simplecoding.repositoryexam.mapper.advanced.GalleryMapper;
import com.simplecoding.repositoryexam.service.advanced.GalleryService;
import com.simplecoding.repositoryexam.vo.common.Criteria;

/**
  * @fileName : GalleryServiceImpl.java
  * @author : KTE
  * @since : 2024. 9. 12. 
  * description :
  */
@Service
public class GalleryServiceImpl implements GalleryService{
	
@Autowired
GalleryMapper galleryMapper;

@Override
public List<?> selectGalleryList(Criteria searchVO) {
	// TODO Auto-generated method stub
	return galleryMapper.selectGalleryList(searchVO);
}

@Override
public int selectGalleryListTotCnt(Criteria searchVO) {
	// TODO Auto-generated method stub
	return galleryMapper.selectGalleryListTotCnt(searchVO);
}









}
