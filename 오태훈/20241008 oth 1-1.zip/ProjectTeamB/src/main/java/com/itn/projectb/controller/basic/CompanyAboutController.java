package com.itn.projectb.controller.basic;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.itn.projectb.service.basic.CompanyAboutService;
import com.itn.projectb.service.basic.ExamService;

import lombok.extern.log4j.Log4j;
import lombok.extern.log4j.Log4j2;

@Log4j
@Controller
public class CompanyAboutController {
	
	@Autowired
	CompanyAboutService companyAboutService;
	
	@GetMapping("/companyabout")
	public String CompanyAboutPage(Model model) {
		List<?> companyaboutList = companyAboutService.selectCompanyAboutList();
		model.addAttribute("companyaboutList", companyaboutList);
		return "mypage/company_all";
	}
}
