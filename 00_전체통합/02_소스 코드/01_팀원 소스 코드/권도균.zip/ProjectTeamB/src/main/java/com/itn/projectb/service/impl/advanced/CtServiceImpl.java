package com.itn.projectb.service.impl.advanced;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itn.projectb.mapper.advanced.CtMapper;
import com.itn.projectb.service.advanced.CtService;
import com.itn.projectb.vo.advanced.Ct4VO;
import com.itn.projectb.vo.advanced.CtVO;
import com.itn.projectb.vo.common.Criteria;

@Service
public class CtServiceImpl implements CtService {

	@Autowired
	CtMapper ctMapper;

	@Override
	public void insertCt(CtVO ctVO) throws Exception {
		// TODO Auto-generated method stub 인서트
		 ctMapper.insert(ctVO);
	}

	@Override
	public List<?> selectCtList(Criteria searchVO) throws Exception {
		// TODO Auto-generated method stub 전체조회
		return ctMapper.selectCtList(searchVO);
	}

	@Override
	public int selectCtListTotCnt(Criteria searchVO) {
		// TODO Auto-generated method stub 페이징
		return ctMapper.selectCtListTotCnt(searchVO);
	}

	@Override
	public void deleteCt(CtVO ctVO) throws Exception {
		// TODO Auto-generated method stub 삭제
		ctMapper.delete(ctVO);
		
	}

	@Override
	public CtVO selectCt(String inid) throws Exception {
		// TODO Auto-generated method stub 상세보기
	       CtVO ctVO = ctMapper.selectCt(inid);
		return ctVO;
	}

	@Override
	public void updateCt(CtVO ctVO) throws Exception {
		// TODO Auto-generated method stub 수정
		ctMapper.update(ctVO);
		
	}

	@Override
	public Ct4VO selectAn(String inid) {
		// TODO Auto-generated method stub
		return ctMapper.selectAn(inid);
	}

	
	

	
	
}
