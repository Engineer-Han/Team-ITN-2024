package com.itn.projectb.controller.basic;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.itn.projectb.service.basic.LocationService;
import com.itn.projectb.service.basic.StoreService;

import lombok.extern.log4j.Log4j;

@Log4j
@Controller
public class LocationController {
	
	@Autowired
	LocationService locationService;
	
	@GetMapping("/location")
	public String StorePage(Model model) {
		List<?> locationList = locationService.selectLocationList();
		model.addAttribute("locationList", locationList);
		return "mypage/location_all";
	}
}
