package com.itn.projectb.service.qna;

import java.util.List;

import com.itn.projectb.vo.common.Criteria;
import com.itn.projectb.vo.qna.QnaVO;

public interface QnaService {
	List<?> selectQnaList(Criteria searchVO) throws Exception;
	int selectQnaListTotCnt(Criteria searchVO);
	void insertQna(QnaVO qnaVO) throws Exception;
	QnaVO selectQna(String faid) throws Exception;
	void updateQnaVO(QnaVO qnaVO) throws Exception;
	void deleteQnaVO(QnaVO qnaVO) throws Exception;
}
