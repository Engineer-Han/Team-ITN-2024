package com.itn.projectb.service.impl.basic;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itn.projectb.mapper.basic.StoreMapper;
import com.itn.projectb.service.basic.StoreService;
import com.itn.projectb.vo.basic.StoreVO;
import com.simplecoding.repositoryexam.vo.common.Criteria;

@Service
public class StoreServiceImpl implements StoreService{
	
	@Autowired
	StoreMapper storeMapper;

	@Override
	public List<?> selectStoreList(Criteria searchVO) {
		// TODO Auto-generated method stub
		return storeMapper.selectStoreList(searchVO);
	}

	@Override
	public void insertStore(StoreVO storeVO) throws Exception {
		// TODO Auto-generated method stub
		storeMapper.insert(storeVO);
	}

	

}
