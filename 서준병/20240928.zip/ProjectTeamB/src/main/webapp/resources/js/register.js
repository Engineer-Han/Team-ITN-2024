const autoSizingSelect = document.getElementById("autoSizingSelect");
const customDomainInput = document.getElementById("customDomainInput");

autoSizingSelect.addEventListener("change", () => {
	const val = autoSizingSelect.value;
	if (val === "direct") {
		customDomainInput.value = "직접입력";
	} else {
		customDomainInput.value = val;
	}
});

function checkPasswordMatch() {
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("inputPasswordConfirm").value;
    var message = document.getElementById("passwordMismatch");
    
    if (password !== confirmPassword) {
        message.style.display = "block"; // 메시지 표시
    } else {
        message.style.display = "none"; // 메시지 숨기기
    }
}

function checkEmailInput() {
    var emailInput = document.getElementById("email1").value;
    var emailWarning = document.getElementById("emailWarning");

    if (emailInput.trim() === "") {
        emailWarning.style.display = "block"; // 경고 메시지 표시
    } else {
        emailWarning.style.display = "none"; // 경고 메시지 숨기기
    }
}
