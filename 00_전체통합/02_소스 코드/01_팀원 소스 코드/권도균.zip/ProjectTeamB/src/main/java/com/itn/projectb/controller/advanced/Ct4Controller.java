package com.itn.projectb.controller.advanced;

import java.util.List;


import javax.annotation.Resource;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springmodules.validation.commons.DefaultBeanValidator;

import com.itn.projectb.service.advanced.Ct4Service;

import com.itn.projectb.vo.advanced.Ct4VO;
import com.itn.projectb.vo.common.Criteria;

import lombok.extern.log4j.Log4j;
@Log4j
@Controller
public class Ct4Controller {
	
	
	
	
	
	
	    
	

	
	
	
	
	
	











	@Autowired
	Ct4Service ct4Service;
	
	  @Resource(name = "beanValidator")
	   protected DefaultBeanValidator beanValidator;
	
//	@GetMapping("/asas")
//	   public String asasView(@RequestParam String inid ,Model model,@ModelAttribute("searchVO") Criteria searchVO) {
//		
//		
//		
//		
//		
//		
//		
//		
//	      return "oneononeas/asas";
//	   }     

	
	
	
	
	@GetMapping("/asas")
	public String selectCt4List(@RequestParam String inid ,Model model,@ModelAttribute("searchVO") Criteria searchVO) throws Exception {
		
		
	

		
		
		List<?> ct4List = ct4Service.selectCt4List(searchVO);
		

		    model.addAttribute("ct4List", ct4List);
		    System.out.println("사랑합니다고객님");
			System.out.println(ct4List);
		
		
		
		
			model.addAttribute("inid",inid);
	
	        return "oneononeas/asas";
		   }
	
	

	


//  저장 버튼 클릭시 실행 함수 : insert 실행 -> post 방식
@PostMapping("/asas")
public String createCt4(@ModelAttribute("Ct4VO") Ct4VO ct4VO) throws Exception {
	System.out.println(ct4VO.getContents());
	System.out.println(ct4VO.getWriter());
	   System.out.println(ct4VO.getInid());
////	  if (ct4VO.getInid() == null || ct4VO.getInid().isEmpty()) {
////	        throw new IllegalArgumentException("inid 값이 필요합니다.");
////	    }
//
////	    log.info("Received inid: " + ct4VO.getInid());
////	    log.info("Received contents: " + ct4VO.getContents());
//	  
////     1) 서비스의 함수 실행 : insert 함수
	   
	   

	   
    
	   ct4Service.insertCt4(ct4VO);
//     
     return "redirect:/oneonone";  // 2) 전제조회 페이지로 강제이동
  }
	
       

	
//상세조회 페이지 열기 :
@GetMapping("/asas/view")
public String updateCt4View(@RequestParam String anid, Model model) 
            throws Exception {
//   1) deptService 의 상세조회 함수 실행 
  Ct4VO ct4VO = ct4Service.selectCt4(anid);
//   2) 모델에 담아 Jsp 로 전송
   model.addAttribute("ct4VO", ct4VO);
   
   
   
   
   
   
   
   
   
   return "oneononeas/asas";
   
   
   
   
   
   
   
}	
	
	
	


	
	
	
	
	
	
	
	
	
	
	
	
	
}
