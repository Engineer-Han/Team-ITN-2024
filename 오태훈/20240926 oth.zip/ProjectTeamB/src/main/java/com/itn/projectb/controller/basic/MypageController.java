/**
 * 
 */
package com.itn.projectb.controller.basic;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

import com.itn.projectb.service.basic.MypageService;
import com.itn.projectb.vo.basic.MypageVO;
import com.simplecoding.repositoryexam.vo.common.Criteria;


/**
  * @fileName : MypageController.java
  * @author : KTE
  * @since : 2024. 9. 26. 
  * description :
  */
@Controller
public class MypageController {
	@Autowired
	private MypageService mypageService;
	@GetMapping("/mypage")
	public String selectMypageList(@ModelAttribute("seachVO") 
	Criteria seachVO, Model model, Criteria searchVO) throws Exception {
		
		List<?> mypages = mypageService.selectMypageList(searchVO);
		model.addAttribute("mypages", mypages);
	


		return "mypage/mypage_all";
	}
	
	/*
	 * @GetMapping("/mypage") public String getMypage(Model model) { List<?>
	 * mypageList = mypageService.selectMypageList(seachVO);
	 * model.addAttribute("mypage", mypageList); }
	 */
	
	@GetMapping("/mypage/mypage/edition")
	public String updateMypageView(@RequestParam String password, Model model) throws Exception {
		MypageVO mypageVO = mypageService.seletMypage(password);
		model.addAttribute("mypageVO", mypageVO);
		return null;
		
	}
	
	public String updateMypage(@RequestParam String password, @ModelAttribute MypageVO mypageVO) throws Exception {
		mypageService.updateMypage(mypageVO);
		return null;
	}
	
}
