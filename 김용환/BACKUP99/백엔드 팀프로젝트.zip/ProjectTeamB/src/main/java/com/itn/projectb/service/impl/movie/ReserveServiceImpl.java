package com.itn.projectb.service.impl.movie;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itn.projectb.mapper.movie.ReserveMapper;
import com.itn.projectb.service.movie.ReserveService;
import com.itn.projectb.vo.movie.ReserveVO;


@Service
public class ReserveServiceImpl implements ReserveService {
    @Autowired
    ReserveMapper reserveMapper;


	@Override
	public List<ReserveVO> selectMovieTitles() {
		// TODO Auto-generated method stub
		return reserveMapper.selectMovieTitles(); // 영화 제목만 반환
	}


	@Override
	public List<ReserveVO> selectTheaterAreas() {
		// TODO Auto-generated method stub
		return reserveMapper.selectTheaterAreas();
	}
    
	
	
    
    
    
}
