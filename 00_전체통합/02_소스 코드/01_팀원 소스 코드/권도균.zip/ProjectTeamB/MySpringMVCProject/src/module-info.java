module MySpringMVCProject {
}