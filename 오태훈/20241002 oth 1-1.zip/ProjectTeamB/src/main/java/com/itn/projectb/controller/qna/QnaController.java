package com.itn.projectb.controller.qna;

import java.util.List;

import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.itn.projectb.service.qna.QnaService;
import com.itn.projectb.vo.common.Criteria;
import com.itn.projectb.vo.qna.QnaVO;

import lombok.Setter;
@Controller
public class QnaController {

	@Autowired
	private QnaService qnaService;
	
	@GetMapping("/qna")
	public String selectQnaList(@ModelAttribute("searchVO") Criteria searchVO
			, Model model) throws Exception {
		
//      TODO: 0) 페이징 변수에 설정 : 
      searchVO.setPageUnit(3); // 1페이지당 화면에 보이는 개수
      searchVO.setPageSize(2); // 페이지 번호를 보여줄 개수
      
//      TODO: 페이지 객체 생성
      PaginationInfo paginationInfo = new PaginationInfo();         // 페이징 객체
      paginationInfo.setCurrentPageNo(searchVO.getPageIndex());     // 현재 페이지 번호 저장
      paginationInfo.setRecordCountPerPage(searchVO.getPageUnit()); // 1페이지당 보일 게시물 개수
      paginationInfo.setPageSize(searchVO.getPageSize());           // 페이지 번호를 보여줄 개수
      
//      TODO: searchVO 객체 페이징 정보 저장
      searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());           // 첫페이지번호
      searchVO.setLastIndex(paginationInfo.getLastRecordIndex());             // 끝페이지번호
      searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage()); // 1페이지당 보일 게시물 개수
 
		
		List<?> qnas = qnaService.selectQnaList(searchVO);
		model.addAttribute("qnas", qnas);
		
		int totCnt = qnaService.selectQnaListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		
//      TODO: 페이징 객체 -> jsp 전달
		model.addAttribute("paginationInfo", paginationInfo);
		
		return "qna/qna_all";
	}
	
	@GetMapping("/qna/addition")
	public String createQnaView(Model model) {
		model.addAttribute("qnaVO", new QnaVO());
		return "qna/add_qna";
	}
	
	@PostMapping("/qna/add")
	public String createQna(@ModelAttribute QnaVO qnaVO
			, BindingResult bindingResult) throws Exception {
		qnaVO.setWriter("joonbyungsuh@naver.com");
		qnaService.insertQna(qnaVO);
		
		
		return "redirect:/qna";
	}
	
	
	
	@GetMapping("/qna/edition")
	public String updateQnaView(@RequestParam String faid
			, Model model) throws Exception {
		QnaVO qnaVO = qnaService.selectQna(faid);
		model.addAttribute("qnaVO", qnaVO);
		return "qna/update_qna";
	}
	
	@PostMapping("/qna/edit")
	public String updateQna(@RequestParam String faid
			, @ModelAttribute QnaVO qnaVO) throws Exception {
		qnaService.updateQnaVO(qnaVO);
		return "redirect:/qna";
	}
	
	@PostMapping("/qna/delete")
	public String deleteQna(@ModelAttribute QnaVO qnaVO) throws Exception {
		qnaService.deleteQnaVO(qnaVO);
		return "redirect:/qna";
	}
}
