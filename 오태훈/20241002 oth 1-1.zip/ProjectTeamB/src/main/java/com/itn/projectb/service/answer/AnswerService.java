package com.itn.projectb.service.answer;

import java.util.List;

import com.itn.projectb.vo.common.Criteria;
import com.itn.projectb.vo.qna.QnaVO;

public interface AnswerService {
	List<?> selectQnaList(Criteria searchVO) throws Exception;
	int selectQnaListTotCnt(Criteria searchVO);
//	void insertQna(QnaVO qnaVO) throws Exception;
//	QnaVO selectQna(String faid) throws Exception;
//	void updateQnaVO(QnaVO qnaVO) throws Exception;
//	void deleteQnaVO(QnaVO qnaVO) throws Exception;
}
