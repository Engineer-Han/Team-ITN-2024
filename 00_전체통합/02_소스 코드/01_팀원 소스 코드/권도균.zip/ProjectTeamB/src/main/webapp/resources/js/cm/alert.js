function log_out() {
    alert("로그아웃되었습니다");
}

function  delete_bt(){
    alert("삭제가 되었습니다")
}

function change_page(){
    alert("페이지가 이동됩니다")
}
function post(){
    alert("게시판으로 이동합니다")
}
function save_bt(){
    alert("저장 되었습니다")
}
