function reservePage(title) {
	location.href = ContextPath + "/reserve?title="+title;
}