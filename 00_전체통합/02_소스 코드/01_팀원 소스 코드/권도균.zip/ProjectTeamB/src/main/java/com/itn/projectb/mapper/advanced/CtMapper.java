package com.itn.projectb.mapper.advanced;

import java.util.List;



import org.apache.ibatis.annotations.Mapper;


import com.itn.projectb.mapper.advanced.CtMapper;
import com.itn.projectb.vo.advanced.Ct4VO;
import com.itn.projectb.vo.advanced.CtVO;
import com.itn.projectb.vo.common.Criteria;


@Mapper
public interface CtMapper {
	public int insert(CtVO ctVO);                   // insert 함수
	public List<?> selectCtList(Criteria searchVO);  //전체조회
	public int selectCtListTotCnt(Criteria searchVO); 
	public int delete(CtVO ctVO);    // 삭제 
	public CtVO selectCt(String inid);                  // 상세조회 함수
	public Ct4VO selectAn(String inid);
	public int update(CtVO ctVO);                   // update 함수

}
