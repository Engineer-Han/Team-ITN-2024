/**
 * 
 */
package com.itn.projectb.controller.auth;

import java.security.Provider.Service;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.itn.projectb.service.auth.MemberService;
import com.itn.projectb.vo.Member.MemberVO;

import lombok.extern.log4j.Log4j;

/**
 * @author
 *
 */
@Log4j
@Controller

public class MemberController {

	@Autowired
	MemberService memberService;

	// 로그인 화면
	@GetMapping("/login")
	public String loginView() {
		return "Login/Login";
	}

	// 로그인 진행
	@PostMapping("/loginProcess")
	public String login(@ModelAttribute MemberVO loginVO, HttpServletRequest request) throws Exception {
		log.info("1 : " + loginVO);
		MemberVO memberVO = memberService.authenticateMember(loginVO);
		log.info("2");
		if (memberVO == null) {
			throw new Exception("없는 회원입니다.");
		}
		request.getSession().setAttribute("memberVO", memberVO);
		return "redirect:/main"; // 메인 페이지 이동
	}

//	회원가입 화면
	@GetMapping("/register")
	public String registerView() {
		return "register/register";
	}


//	회원가입 
	@PostMapping("/register/addition")
	public String register(@ModelAttribute("memberVO") MemberVO memberVO, 
												@RequestParam("passwordConfirm") String passwordConfirm, 																					
																					Model model) throws Exception {
		log.info("테스트 : " + memberVO);
//		이미 가입된 회원 확인
		MemberVO memberVO2 = memberService.authenticateMember(memberVO);
		if (memberVO2 != null) {
			 // 이메일이 이미 존재하는 경우
	        model.addAttribute("emailMessage", "이미 가입되어 있습니다.");  // 메시지 추가
	        // 다시 등록 페이지로 이동
			return "redirect:/register";
		}else {
			model.addAttribute("emailMessage", "사용 가능한 이메일입니다.");
		}
		// 비밀번호 확인
	    if (!memberVO.getPassword().equals(passwordConfirm)) {
	        model.addAttribute("errorMessage", "비밀번호가 일치하지 않습니다.");
	        model.addAttribute("memberVO", memberVO);
	        return "register/register"; // 비밀번호 불일치 시 등록 페이지로 이동
	    }

		memberService.registerMember(memberVO);
		
		return "redirect:/main";
	}

	@PostMapping(value = "/checkEmail", produces = "application/json; charset=UTF-8")	
	@ResponseBody
	public ResponseEntity<String> checkEmail(@RequestBody MemberVO memberVO) throws Exception {		 
		
		boolean isDuplicate = memberService.checkEmailDuplicate(memberVO);
		if (isDuplicate) {
			return ResponseEntity.ok("중복된 이메일입니다.");
		} else {
			return ResponseEntity.ok("사용 가능한 이메일 입니다.");
		}
	}

	

	

}
