/**
 * 
 */
package com.itn.projectb.service.impl.basic;

import java.util.List;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itn.projectb.mapper.basic.MypageMapper;
import com.itn.projectb.service.basic.MypageService;
import com.itn.projectb.vo.basic.MypageVO;
import com.simplecoding.repositoryexam.vo.common.Criteria;

/**
  * @fileName : MypageServiceImpl.java
  * @author : KTE
  * @since : 2024. 9. 26. 
  * description :
  */
@Service
public class MypageServiceImpl implements MypageService{

	@Autowired
	MypageMapper mypageMapper;


	@Override
	public List<?> selectMypageList(Criteria seachVO) throws Exception {
		return mypageMapper.selectMypageList(seachVO);
	}


	@Override
	public MypageVO authenticateMypage(MypageVO loginVO) throws Exception {
		MypageVO mypageVO = mypageMapper.authenticate(loginVO);
		if (mypageVO != null) {
			boolean isMatchedPassword = BCrypt.checkpw(loginVO.getPassword(), mypageVO.getPassword());
			if (isMatchedPassword == false) {
				throw new Exception("암호가 틀립니다.");
			}
		}
		
		return mypageVO;
	}


	@Override
	public MypageVO seletMypage(String password) throws Exception {
		// TODO Auto-generated method stub
		MypageVO mypageVO = mypageMapper.selectMypage(password);
		return null;
	}


	@Override
	public void updateMypage(MypageVO mypageVO) throws Exception {
		// TODO Auto-generated method stub
		mypageMapper.update(mypageVO);
		
	}


	

	
	
}
