package com.itn.projectb.service.advanced;

import java.util.List;

import com.itn.projectb.vo.advanced.Ct2VO;
import com.itn.projectb.vo.common.Criteria;

public interface Ct2Service {

	
	
	public List<?> selectCt2List(Criteria searchVO)  throws Exception; // 전체조회 함수
	public int selectCt2ListTotCnt(Criteria searchVO); // 페이징
	 Ct2VO selectCt2(String faid) throws Exception; // 상세보기
	
	
}
