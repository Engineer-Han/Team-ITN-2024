package com.itn.projectb.service.basic;

import java.util.List;

import com.itn.projectb.vo.basic.StoreVO;
import com.simplecoding.repositoryexam.vo.common.Criteria;

public interface StoreService {
	public List<?> selectStoreList(Criteria searchVO) throws Exception; 
	void insertStore(StoreVO storeVO) throws Exception;
}
