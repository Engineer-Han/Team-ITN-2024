package com.itn.projectb.service.impl.basic;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itn.projectb.mapper.basic.LocationMapper;
import com.itn.projectb.mapper.basic.StoreMapper;
import com.itn.projectb.service.basic.LocationService;
import com.itn.projectb.service.basic.StoreService;

@Service
public class LocationServiceImpl implements LocationService{
	
	@Autowired
	LocationMapper locationMapper;

	@Override
	public List<?> selectLocationList() {
		// TODO Auto-generated method stub
		return locationMapper.selectLocationList();
	}

	

}
