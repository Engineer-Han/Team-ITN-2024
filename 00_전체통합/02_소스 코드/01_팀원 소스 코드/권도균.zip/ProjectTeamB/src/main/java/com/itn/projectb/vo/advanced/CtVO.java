package com.itn.projectb.vo.advanced;

import com.itn.projectb.vo.common.Criteria;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@SuppressWarnings("serial")
public class CtVO extends Criteria {
//	클래스의 3요소 : 속성(필드), 생성자, 함수(Setter/Getter)
	
	
//	Faid, Title, Contents, Writer, Insert_Time, Update_Time

	private String inid;
	private String contents;  
	private String writer;
	private String insertTime;
	




        
       
    }

    