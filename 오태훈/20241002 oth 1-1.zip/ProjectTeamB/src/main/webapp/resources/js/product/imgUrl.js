const imageUrls = {
    IMAGE_MAIN_URL: null,
    IMAGE_SMALL_URL: null,
    IMAGE_BACKGROUND_URL: null,
    IMAGE_THRIL1_URL: null,
    IMAGE_THRIL2_URL: null,
    IMAGE_THRIL3_URL: null
};

function handleFileSelect(event, imageType) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            imageUrls[imageType] = e.target.result; // 파일의 Base64 URL 저장
            console.log(`${imageType} has been set: `, imageUrls[imageType]);
        };
        reader.readAsDataURL(file); // 파일을 Base64 URL로 읽어옴
    }
}
