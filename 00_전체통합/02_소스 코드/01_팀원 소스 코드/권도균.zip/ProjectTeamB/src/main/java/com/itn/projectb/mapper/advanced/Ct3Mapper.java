package com.itn.projectb.mapper.advanced;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.itn.projectb.vo.advanced.Ct3VO;
import com.itn.projectb.vo.common.Criteria;

@Mapper
public interface Ct3Mapper {

	
	
	
	public List<?> selectCt3List(Criteria searchVO);  //전체조회
	public int selectCt3ListTotCnt(Criteria searchVO); //페이징
	public Ct3VO selectCt3(String noid);  //상세조회

	
	
	
	
}
