function faqPage(){
	location.href =  ContextPath + "/faqList";
}