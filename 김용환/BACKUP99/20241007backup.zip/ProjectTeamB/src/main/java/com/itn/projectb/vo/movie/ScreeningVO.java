package com.itn.projectb.vo.movie;

public class ScreeningVO {

	private String scid;
    private String title;
    private String cinema;
    private String branch; 
    private int theater;    
    private int seats;
    private int remainSeats;
    private String showingTime;
    private String insertTime;
    private String updateTime;
    private String city;
    private String startTime;
    private String endTime;
    public String getReservedSeat() {
		return reservedSeat;
	}
	public void setReservedSeat(String reservedSeat) {
		this.reservedSeat = reservedSeat;
	}
	private String reservedSeat;
    
    
	public String getScid() {
		return scid;
	}
	public void setScid(String scid) {
		this.scid = scid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCinema() {
		return cinema;
	}
	public void setCinema(String cinema) {
		this.cinema = cinema;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public int getTheater() {
		return theater;
	}
	public void setTheater(int theater) {
		this.theater = theater;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public int getRemainSeats() {
		return remainSeats;
	}
	public void setRemainSeats(int remainSeats) {
		this.remainSeats = remainSeats;
	}
	public String getShowingTime() {
		return showingTime;
	}
	public void setShowingTime(String showingTime) {
		this.showingTime = showingTime;
	}
	public String getInsertTime() {
		return insertTime;
	}
	public void setInsertTime(String insertTime) {
		this.insertTime = insertTime;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
    

    
    
	
}
