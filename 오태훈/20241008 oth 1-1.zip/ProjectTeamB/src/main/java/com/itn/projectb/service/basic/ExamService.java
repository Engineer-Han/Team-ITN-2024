package com.itn.projectb.service.basic;

import java.util.List;

public interface ExamService {
	public List<?> selectExamList(); 
}
