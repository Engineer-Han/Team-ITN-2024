package com.itn.projectb.service.movie_all;

import java.util.List;

import org.springframework.stereotype.Service;

import com.itn.projectb.vo.movie_all.Movie_allVO;
import com.itn.projectb.vo.movie_all.Movie_reviewVO;
import com.itn.projectb.vo.common.Criteria;
@Service
public interface Movie_allService {
	Movie_allVO selectMovie_all(String pdid) throws Exception;     // 상세 조회
//	public List<?> selectMovie_allList(); 
	List<?> selectMovie_allList(Criteria searchVO) throws Exception;
	int selectMovie_allListTotCnt(Criteria searchVO);     // 개수 세기 
	void insertMovie_all(Movie_allVO movie_allVO) throws Exception; // insert 함수
	void review_register(Movie_allVO movie_allVO) throws Exception; // 영화 실관람평 리뷰 등록

	
	List<?> selectMovie_reviews(String pdid) throws Exception; // 영화 실관람평 리뷰 상세 조회
	int selectMovie_reviewsTotCnt(Criteria search_reaviewsVO); // 영화 실관람평 리뷰 개수 세기
	
}
