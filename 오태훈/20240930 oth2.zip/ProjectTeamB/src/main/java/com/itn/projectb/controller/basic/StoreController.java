package com.itn.projectb.controller.basic;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.itn.projectb.service.basic.StoreService;
import com.itn.projectb.vo.basic.StoreVO;
import com.simplecoding.repositoryexam.vo.common.Criteria;


@Controller
public class StoreController {
	
	@Autowired
	StoreService storeService;
	
	@GetMapping("/store")
	public String StorePage(Model model, Criteria searchVO) throws Exception {
		List<?> storeList = storeService.selectStoreList(searchVO);
		model.addAttribute("storeList", storeList);
		return "mypage/store_all";
	}
	@PostMapping("/mypage/store/add")
	public String creatStore(@ModelAttribute StoreVO storeVO, BindingResult bindingResult)
	throws Exception {
		storeService.insertStore(storeVO);
		
		return "redirect:/mypage/store";
	}
}
