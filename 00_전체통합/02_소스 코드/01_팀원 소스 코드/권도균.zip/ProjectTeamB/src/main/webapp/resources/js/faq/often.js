 
const inquiryForm = document.getElementById("inquiryForm");

const write = document.getElementById("wirte");
const inquiryTitle = document.getElementById("inquiryTitle");
const inquiryMessage = document.getElementById("inquiryMessage");

const fn_egov_link_page = (pageNo) => {
		listForm.pageIndex.value = pageNo;
		listForm.action = ContextPath + "/often";
		listForm.submit();
}

write.addEventListener("click", ()=> {
	if (!inquiryTitle.value )  {
		alert ("제목을 입력해주세요");
		return false;
	 }
	if (!inquiryMessage.value  )  {
		alert ("내용을 입력해주세요");
		return false;
	 }
inquiryForm.action= ContextPath+"/often/write";
inquiryForm.submit();

 } );