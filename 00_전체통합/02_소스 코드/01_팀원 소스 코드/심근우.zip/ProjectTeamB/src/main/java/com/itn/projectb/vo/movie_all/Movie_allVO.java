package com.itn.projectb.vo.movie_all;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Movie_allVO {
	
	private String pdid;
	private String title;
	private String contents;
	private String director;
	private String genre;
	private int runningTime;
	private String rate;
	private String openingDate;
	private String movieCast;
	private String imageMainUrl;   // 내부적 사용(이미지)
	private String imageSmallUrl;   // 내부적 사용(이미지)
	private String imageBackgroundUrl;   // 내부적 사용(이미지)
	private String imageThril1Url;   // 내부적 사용(이미지)
	private String imageThril2Url;   // 내부적 사용(이미지)
	private String imageThril3Url;   // 내부적 사용(이미지)
	private String trailerMainUrl; // 다운로드 url
	private String trailer1Url; // 다운로드 url
	private String trailer2Url; // 다운로드 url
	private int cumulative;
	private int	happyPoint;
	private String insertTime;
	private String updateTime;
	private String rateUrl;
	
	// 영화 실관람평 리뷰 관련 VO
	private String prid;
	private String review;
	private String writer;
	
		
	
	
	
}
//	Pdid
//	Title
//	Contents
//	Director
//	Genre
//	Running_Time
//	Rate
//	Opening_Date
//	Movie_Cast
//	Image_Main_Url
//	Image_Small_Url
//	Image_Background_Url
	
//	Image_Thril1_Url
//	Image_Thril2_Url
//	Image_Thril3_Url
	
//	Trailer_Main_Url
//	Trailer1_Url
//	Trailer2_Url

