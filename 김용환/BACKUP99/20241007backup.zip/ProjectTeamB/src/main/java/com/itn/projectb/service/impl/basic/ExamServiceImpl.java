package com.itn.projectb.service.impl.basic;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itn.projectb.mapper.basic.ExamMapper;
import com.itn.projectb.service.basic.ExamService;

@Service
public class ExamServiceImpl implements ExamService{
	
	@Autowired
	ExamMapper examMapper;

	@Override
	public List<?> selectExamList() {
		return examMapper.selectExamList();
	}

}
