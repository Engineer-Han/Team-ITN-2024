/**
 * 
 */
package com.itn.projectb.service.basic;

import java.util.List;

import org.springframework.stereotype.Service;

import com.itn.projectb.vo.basic.MypageVO;
import com.simplecoding.repositoryexam.vo.common.Criteria;

/**
 * @fileName : MypageService.java
 * @author : KTE
 * @since : 2024. 9. 26. description :
 */
@Service
public interface MypageService {
	public List<?> selectMypageMemberList(Criteria seachVO) throws Exception;
	public List<?> selectMypageBookList(Criteria seachVO) throws Exception;
	public List<?> selectMypagePayList(Criteria seachVO) throws Exception;
	
//	int selectMypageListTotCnt(Criteria searchVO);


	MypageVO selectMypageMember(String password) throws Exception;
	MypageVO selectMypageBook(String boid) throws Exception;
	MypageVO selectMypagePay(String boid) throws Exception;

	void updateMypageMember(MypageVO mypageVO) throws Exception;
	void updateMypageBook(MypageVO mypageVO) throws Exception;
	void updateMypagePay(MypageVO mypageVO) throws Exception;
	
	public MypageVO authenticateMypage(MypageVO loginVO) throws Exception;
}
