package com.itn.projectb.service.basic;

import java.util.List;

public interface CompanyAboutService {
	public List<?> selectCompanyAboutList(); 
}
