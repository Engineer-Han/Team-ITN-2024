package com.itn.projectb.service.advanced;

import java.util.List;

import com.itn.projectb.vo.advanced.Ct4VO;

import com.itn.projectb.vo.common.Criteria;

public interface Ct4Service {

	
	public List<?> selectCt4List(Criteria searchVO)  throws Exception; // 전체조회 함수
	public int selectCt4ListTotCnt(Criteria searchVO); // 페이징
	public int insertCt4(Ct4VO ct4VO) throws Exception;
	 Ct4VO selectCt4(String anid) throws Exception; // 상세보기
	
}
