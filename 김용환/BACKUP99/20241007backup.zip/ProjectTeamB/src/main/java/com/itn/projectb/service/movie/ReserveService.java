package com.itn.projectb.service.movie;

import java.util.List;
import java.util.Map;

import com.itn.projectb.vo.movie.CinemaVO;
import com.itn.projectb.vo.movie.ScreeningVO;

public interface ReserveService {
	 List<ScreeningVO> getMoviesByDate(String date); // 날짜에 맞는 영화 목록 가져오기

	 List<ScreeningVO> getScreeningInfo(Map<String, Object> params);
    
}