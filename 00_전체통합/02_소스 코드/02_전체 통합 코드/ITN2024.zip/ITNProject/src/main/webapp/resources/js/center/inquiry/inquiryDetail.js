function AnswerPage(inid){
	location.href =  ContextPath + "/inquiryAnswer?inid="+inid;
}

function InquiryPage(){
	location.href =  ContextPath + "/inquiryList";
}