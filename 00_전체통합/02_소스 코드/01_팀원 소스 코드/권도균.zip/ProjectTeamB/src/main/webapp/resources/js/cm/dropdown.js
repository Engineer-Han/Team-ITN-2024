document.addEventListener('DOMContentLoaded', function () {
    const dropdownToggle = document.getElementById('menu4'); // 드롭다운 버튼
    const dropdownContent = document.querySelector('.dropdown-content'); // 드롭다운 메뉴
    let isDropdownOpen = false; // 드롭다운 상태 추적

    // 현재 페이지가 드롭다운 항목과 일치하는지 확인하는 함수
    function isDropdownActive() {
        return window.location.pathname.includes('add_movie.html') || 
               window.location.pathname.includes('add_screening_list.html') || 
               window.location.pathname.includes('movie_list.html');
    }

    // 드롭다운 항목이 활성화되어 있을 때 스타일 변경
    function updateDropdownStyle() {
        const dropdownItems = dropdownContent.querySelectorAll('.dropdown-item');

        dropdownItems.forEach(item => {
            const targetPage = item.id === 'menu4_1' ? 'add_movie.html' :
                               item.id === 'menu4_2' ? 'add_screening_list.html' :
                               item.id === 'menu4_3' ? 'movie_list.html' : '';

            if (window.location.pathname.includes(targetPage)) {
                item.classList.add('active'); // 활성화 스타일 추가
                dropdownToggle.classList.add('active-dropdown'); // 드롭다운 버튼 스타일 추가
                dropdownContent.style.display = 'block'; // 드롭다운 유지
            } else {
                item.classList.remove('active'); // 활성화 스타일 제거
            }
        });
    }

    // 드롭다운 토글: 버튼 클릭 시 드롭다운 열기/닫기
    dropdownToggle.addEventListener('click', function (event) {
        event.preventDefault();
        isDropdownOpen = !isDropdownOpen;
        dropdownContent.style.display = isDropdownOpen ? 'block' : 'none';

        // 드롭다운 열기 시 스타일 업데이트
        if (isDropdownOpen) {
            updateDropdownStyle(); // 드롭다운 상태 업데이트
        }

        event.stopPropagation(); // 이벤트 전파 방지
    });

    // 드롭다운 메뉴 클릭 시 (메뉴 안의 항목 클릭 처리)
    dropdownContent.addEventListener('click', function (event) {
        const target = event.target;

        if (target.classList.contains('dropdown-item')) {
            // 클릭한 드롭다운 항목이 있을 때, 페이지 이동 및 드롭다운 닫기
            isDropdownOpen = false; // 드롭다운 상태 업데이트
            dropdownContent.style.display = 'none'; // 드롭다운 닫기

            // 페이지 이동 처리
            if (target.id === 'menu4_1') {
                window.location.href = 'add_movie.html';
            } else if (target.id === 'menu4_2') {
                window.location.href = 'add_screening_list.html';
            } else if (target.id === 'menu4_3') {
                window.location.href = 'movie_list.html';
            }

            event.stopPropagation(); // 이벤트 전파 방지
        }
    });

    // 페이지 로드 시 드롭다운 상태 업데이트
    updateDropdownStyle();

    // 페이지 외부 클릭 시 드롭다운 유지
    document.addEventListener('click', function (event) {
        const isClickInsideDropdown = dropdownToggle.contains(event.target) || dropdownContent.contains(event.target);

        if (!isClickInsideDropdown) {
            // 드롭다운 항목이 활성화되어 있을 때 드롭다운 유지
            if (isDropdownActive()) {
                dropdownContent.style.display = 'block'; // 드롭다운 유지
            } else {
                dropdownContent.style.display = 'none'; // 드롭다운 닫기
                dropdownToggle.classList.remove('active-dropdown'); // 원래 스타일로 복구
            }
        }
    });
});
