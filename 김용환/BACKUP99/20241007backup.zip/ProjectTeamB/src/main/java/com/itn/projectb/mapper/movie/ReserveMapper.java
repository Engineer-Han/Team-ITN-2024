package com.itn.projectb.mapper.movie;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.itn.projectb.vo.movie.CinemaVO;
import com.itn.projectb.vo.movie.ScreeningVO;

@Mapper
public interface ReserveMapper {
	List<ScreeningVO>getMoviesByDate(String date);
	
	 List<ScreeningVO> getScreeningInfo(Map<String, Object> params);
}


