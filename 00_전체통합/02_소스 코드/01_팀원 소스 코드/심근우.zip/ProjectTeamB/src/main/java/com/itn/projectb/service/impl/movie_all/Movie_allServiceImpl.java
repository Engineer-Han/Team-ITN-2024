package com.itn.projectb.service.impl.movie_all;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itn.projectb.mapper.movie_all.Movie_allMapper;
import com.itn.projectb.service.movie_all.Movie_allService;
import com.itn.projectb.vo.movie_all.Movie_allVO;
import com.itn.projectb.vo.common.Criteria;

@Service
public class Movie_allServiceImpl implements Movie_allService{
	
	@Autowired
	Movie_allMapper movie_allMapper;

	
	

	//	함수 재정의 : source
	@Override
	public List<?> selectMovie_allList(Criteria searchVO) throws Exception {
		// TODO : 전체 조회
		return movie_allMapper.selectMovie_allList(searchVO);
	}
	
//	개수 세기 함수 : source 
	@Override
	public int selectMovie_allListTotCnt(Criteria searchVO) {
		// TODO deptMapper.개수세기함수 실행
		return movie_allMapper.selectMovie_allListTotCnt(searchVO);
	}
//	insert 함수 : source 
	@Override
	public void insertMovie_all(Movie_allVO movie_allVO) throws Exception {
		// TODO deptMapper 의 insert 함수 실행 : 내부 sql 문 실행
		movie_allMapper.insert(movie_allVO);
	}
	
	
//	상세조회 : source
	@Override
	public Movie_allVO selectMovie_all(String pdid) throws Exception {
		// TODO deptMapper 의 상세조회 함수 실행
		
		Movie_allVO movie_allVO = movie_allMapper.selectMovie_all(pdid);
		return movie_allVO;
	}

	@Override // 영화 실관람평 리뷰 등록
	public void review_register(Movie_allVO movie_allVO) throws Exception {
		// title가 PRODUCT_TB에 존재하는지 확인
		String title = movie_allVO.getTitle();
		System.out.println("Title: " + title); // 디버깅을 위한 출력

	    int productCount = movie_allMapper.selectProductCount(movie_allVO.getTitle());
	    
	    if (productCount > 0) {
	        
	        movie_allMapper.review_register(movie_allVO);
	    } else {
	       
	        throw new Exception("Invalid title: " + movie_allVO.getTitle());
	    }
	}
	
	@Override
	public List<?> selectMovie_reviews(String pdid) throws Exception {
		// TODO Auto-generated method stub
		return movie_allMapper.selectMovie_reviews(pdid);
		
	}

	@Override
	public int selectMovie_reviewsTotCnt(Criteria search_reaviewsVO) {
		// TODO Auto-generated method stub
		return movie_allMapper.selectMovie_reviewsTotCnt(search_reaviewsVO);
	}

	
	
}
