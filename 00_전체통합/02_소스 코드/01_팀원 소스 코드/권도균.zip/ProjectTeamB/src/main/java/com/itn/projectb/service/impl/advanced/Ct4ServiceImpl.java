package com.itn.projectb.service.impl.advanced;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itn.projectb.mapper.advanced.Ct4Mapper;
import com.itn.projectb.service.advanced.Ct4Service;
import com.itn.projectb.vo.advanced.Ct4VO;
import com.itn.projectb.vo.common.Criteria;

@Service
public class Ct4ServiceImpl implements Ct4Service {

	@Autowired
	Ct4Mapper ct4Mapper;

	@Override
	public List<?> selectCt4List(Criteria searchVO) throws Exception {
		// TODO Auto-generated method stub
		return ct4Mapper.selectCt4List(searchVO);
	}

	@Override
	public int selectCt4ListTotCnt(Criteria searchVO) {
		// TODO Auto-generated method stub
		return ct4Mapper.selectCt4ListTotCnt(searchVO);
	}

	@Override
	public int insertCt4(Ct4VO ct4vo) throws Exception {
		// TODO Auto-generated method stub
		return ct4Mapper.insert(ct4vo);
	}

	@Override
	public Ct4VO selectCt4(String anid) throws Exception {
		// TODO Auto-generated method stub
		Ct4VO ct4vo = ct4Mapper.selectCt4(anid);
		return ct4vo;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
