/**
 * 
 */
package com.itn.projectb.controller.basic;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.itn.projectb.service.basic.MypageService;
import com.itn.projectb.vo.basic.MypageVO;
import com.simplecoding.repositoryexam.vo.common.Criteria;

import lombok.extern.log4j.Log4j;

/**
 * @fileName : MypageController.java
 * @author : KTE
 * @since : 2024. 9. 26. description :
 */
@Log4j
@Controller
public class MypageController {
	@Autowired
	private MypageService mypageService;

	@GetMapping("/mypage")
	public String selectMypageList(@ModelAttribute("seachVO") Criteria seachVO, Model model, Criteria searchVO)
			throws Exception {

//		//      TODO: 0) 페이징 변수에 설정 : 
//		      searchVO.setPageUnit(3); // 1페이지당 화면에 보이는 개수
//		      searchVO.setPageSize(2); // 페이지 번호를 보여줄 개수
//		      
//		//      TODO: 페이지 객체 생성
//		      PaginationInfo paginationInfo = new PaginationInfo();         // 페이징 객체
//		      paginationInfo.setCurrentPageNo(searchVO.getPageIndex());     // 현재 페이지 번호 저장
//		      paginationInfo.setRecordCountPerPage(searchVO.getPageUnit()); // 1페이지당 보일 게시물 개수
//		      paginationInfo.setPageSize(searchVO.getPageSize());           // 페이지 번호를 보여줄 개수
//		      
//		//      TODO: searchVO 객체 페이징 정보 저장
//		      searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());           // 첫페이지번호
//		      searchVO.setLastIndex(paginationInfo.getLastRecordIndex());             // 끝페이지번호
//		      searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage()); // 1페이지당 보일 게시물 개수

////      TODO: 3) 부서 테이블의 총개수(서비스 객체의 함수를 실행) : 페이지 객체 저장
//      int totCnt = mypageService.selectMypageListTotCnt(searchVO);
//      paginationInfo.setTotalRecordCount(totCnt);
//      model.addAttribute("paginationInfo", paginationInfo);		

		List<?> mypagesMember = mypageService.selectMypageMemberList(searchVO);
		model.addAttribute("mypagesMember", mypagesMember);

		List<?> mypagesBook = mypageService.selectMypageBookList(searchVO);
		model.addAttribute("mypagesBook", mypagesBook);

		List<?> mypagesPay = mypageService.selectMypagePayList(searchVO);
		model.addAttribute("mypagesPay", mypagesPay);

		return "mypage/mypage_all";
	}

	@GetMapping("/mypage/editionMember")
	public String updateMypageMemberView(@RequestParam String password, Model model) throws Exception {
		MypageVO mypageVO = mypageService.selectMypageMember(password);
		model.addAttribute("mypageVO", mypageVO);
		return null;
	}

	@GetMapping("/mypage/editionBook")
	public String updateMypageBookView(@RequestParam String boid, Model model) throws Exception {
		MypageVO mypageVO = mypageService.selectMypageBook(boid);
		model.addAttribute("mypageVO", mypageVO);
		return null;
	}

	@PostMapping("/mypage/editMember")
	public String updateMypageMember(@RequestParam String password, @ModelAttribute MypageVO mypageVO)
			throws Exception {

		mypageService.updateMypageMember(mypageVO);

		return "redirect:/mypage";
	}

	@PostMapping("/mypage/editBook")
	public String updateMypageBook(@RequestParam String boid, @ModelAttribute MypageVO mypageVO) throws Exception {

		mypageService.updateMypageBook(mypageVO);
		mypageService.updateMypagePay(mypageVO);

		return "redirect:/mypage";
	}

	@PostMapping("/mypage/editPay")
	public String updateMypagePay(@RequestParam String boid, @ModelAttribute MypageVO mypageVO) throws Exception {

		mypageService.updateMypagePay(mypageVO);
		mypageService.updateMypageBook(mypageVO);

		return "redirect:/mypage";
	}

}
