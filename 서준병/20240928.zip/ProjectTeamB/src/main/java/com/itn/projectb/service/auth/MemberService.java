package com.itn.projectb.service.auth;

import org.springframework.stereotype.Service;

import com.itn.projectb.vo.Member.MemberVO;

public interface MemberService {
	public MemberVO authenticateMember(MemberVO loginVO) throws Exception;
	public void registerMember(MemberVO memberVO) throws Exception;
	
	
}
