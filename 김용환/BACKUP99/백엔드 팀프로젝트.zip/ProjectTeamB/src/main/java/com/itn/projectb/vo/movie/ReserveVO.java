/**
 * 
 */
package com.itn.projectb.vo.movie;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
  * @fileName : ReserveVO.java
  * @author : KTE
  * @since : 2024. 9. 27. ㅡ
  * description :
  */

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ReserveVO {
public String 
movieTitle, 
theaterArea, 
theaterTitle, 
theaterNum, 
startTime,
endTime;



}
