package com.itn.projectb.vo.movie_all;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Movie_reviewVO {
	// 영화 실관람평 리뷰 관련 VO
	private String prid;
	private String pdid;
	private String review;
	private String writer;
	


}
