const headerMovie = () => {
	location.href=ContextPath + "/movie_all";
}
const headerCenter = () => {
	location.href=ContextPath + "/noticeAll";
}

const headerSignin = () =>{
	location.href=ContextPath + "/login";
} 

const headerSignOut = () => {
	location.href=ContextPath + "/logout";
}

const headerSignup = () => {
	location.href=ContextPath + "/register";
}

const headerMypage = () => {
	location.href=ContextPath + "/mypage";
}

const headerAdmin = () => {
	location.href=ContextPath + "/admin/main";
}

const headerReserve = () => {
	location.href=ContextPath + "/reserve";
}