<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- jQuery CDN 추가 -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap CDN 추가 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Bootstrap JS 추가 -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <script type="text/javascript" defer="defer">
    //구매취소 버튼
  $(document).ready(function () {
    // 환불 버튼 클릭 시 동작하는 함수
    $(".btn-primary").click(function () {
      // 버튼 비활성화
      $(this).prop("disabled", true);
      $(this).removeClass("btn-primary").addClass("btn-secondary").text("취소완료");

      // 결제 상태 변경
      var row = $(this).closest("tr"); // 클릭된 버튼이 있는 행을 찾음
      row.find("td:nth-child(6)").text("취소완료");

      // 환불 내역 테이블에 추가
      var product = row.find("td:nth-child(2)").text(); // 상품명
      var price = row.find("td:nth-child(3)").text(); // 결제금액
      var refundRow = `<tr>
        <th scope="row">2024-01</th>
        <td>${loc}</td>
        <td>환불</td>
        <td>${product}</td>
        <td>${price}</td>
        <td>결제취소 완료</td>
      </tr>`;
      $("#refundTable tbody").append(refundRow); // 환불 테이블에 새로운 행 추가
    });
  });
  
  // 회원정보 열람
  function checkPassword() {
	    const passwordInput = document.getElementById("floatingPassword").value;
	    const correctPassword = "your_password"; // Replace with the correct password

	    if (passwordInput === "123456") {
	      document.getElementById("info-section").style.display = "block";
	      document.getElementById("password-section").style.display = "none";
	    } else {
	      alert("비밀번호가 잘못되었습니다.");
	    }
	  }
  
//수정 버튼 클릭시 실행함수
  function fn_save() {
//     1) action 속성 : "/basic/dept/edit"
    document.detailForm.action = "/mypage";
//     2) submit() 실행
    document.detailForm.submit();
 }
</script>
    
  </head>
  <body>
  <jsp:include page="/common/header.jsp"></jsp:include>
    <!-- mypage start -->

    <!-- body background color -->
    <div style="background-color: white">
      <!-- Main Content -->
      <div
        class="d-flex justify-content-center"
        style="height: 100vh; padding-top: 50px"
      >
        <div class="row" style="width: 80%">
          <!-- Sidebar Navigation -->
          <div class="col-2">
            <div class="list-group" id="list-tab" role="tablist">
              <a
                class="list-group-item list-group-item-action active"
                style="
                  background-color: rgb(207, 226, 255);
                  color: black;
                  border: 3px solid rgb(207, 226, 255);
                  height: 60px;
                  font-size: 25px;
                "
                data-bs-toggle="list"
                href="#list-mypagehome"
                role="tab"
                >마이페이지</a
              >
              <a
                class="list-group-item list-group-item-action"
                data-bs-toggle="list"
                href="#list-reservation"
                role="tab"
                >예매/구매 내역</a
              >
              <a
                class="list-group-item list-group-item-action"
                data-bs-toggle="list"
                href="#list-refund"
                role="tab"
              >
                &nbsp; 환불 내역</a
              >
              <a
                class="list-group-item list-group-item-action"
                data-bs-toggle="list"
                href="#list-ticket"
                role="tab"
                >영화 관람권</a
              >
              <a
                class="list-group-item list-group-item-action"
                data-bs-toggle="list"
                href="#list-qna"
                role="tab"
                >문의 내역</a
              >
              <a
                class="list-group-item list-group-item-action"
                data-bs-toggle="list"
                href="#list-information"
                role="tab"
                >회원정보</a
              >
            </div>
          </div>

          <!-- Tab Content -->
          <div class="col-8">
            <div
              class="tab-content"
              id="nav-tabContent"
              style="
                border: 1px solid gray;
                border-radius: 5px;
                margin-top: 10px;
                padding: 20px;
                background-color: white;
              "
            >
              <!-- Home Tab -->
              <div
                class="tab-pane fade show active"
                id="list-mypagehome"
                role="tabpanel"
                style="font-size: 50px; color: black"
              >
                환영합니다 회원님!
              </div>

              <!-- Reservation Tab -->
              <div class="tab-pane fade" id="list-reservation" role="tabpanel">
                <p style="font-size: 30px; color: black">예매/구매 내역</p>
                <nav>
                  <div class="nav nav-tabs" id="nav-tab" role="tablist">
                    <button
                      class="nav-link active"
                      id="nav-home-tab"
                      data-bs-toggle="tab"
                      data-bs-target="#nav-home"
                      type="button"
                      role="tab"
                      aria-controls="nav-home"
                      aria-selected="true"
                      style="font-weight: bold"
                    >
                      예매
                    </button>
                    <button
                      class="nav-link"
                      id="nav-profile-tab"
                      data-bs-toggle="tab"
                      data-bs-target="#nav-profile"
                      type="button"
                      role="tab"
                      aria-controls="nav-profile"
                      aria-selected="false"
                      style="font-weight: bold"
                    >
                      구매
                    </button>
                  </div>
                </nav>
                <div class="tab-content" id="nav-tabContent">
                  <!-- 예매 내역 -->
                  <div
                    class="tab-pane fade show active"
                    id="nav-home"
                    role="tabpanel"
                    aria-labelledby="nav-home-tab"
                    tabindex="0"
                  >
                    <table
                      class="table table-striped"
                      style="background-color: white"
                    >
                      <br />
                      <thead>
                        <tr class="table-primary">
                          <th scope="col">예매일</th>
                          <th scope="col">영화관</th>
                          <th scope="col">영화</th>
                          <th scope="col">관람좌석</th>
                          <th scope="col">예매취소</th>
                          <th scope="col">상태</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">2024-03</th>
                          <td>동래</td>
                          <td>대도시의 사랑법</td>
                          <td>I-4</td>
                          <td>
                            <button
                              type="button"
                              class="btn btn-primary btn-sm"
                            >
                              예매취소
                            </button>
                          </td>
                          <td>취소가능</td>
                        </tr>
                        <tr>
                          <th scope="row">2024-02</th>
                          <td>동래</td>
                          <td>베테랑</td>
                          <td>G-5</td>
                          <td>
                            <button
                              type="button"
                              class="btn btn-secondary btn-sm"
                              disabled
                            >
                              예매취소
                            </button>
                          </td>
                          <td>기간만료</td>
                        </tr>
                        <tr>
                          <th scope="row">2024-01</th>
                          <td>동래</td>
                          <td>조커</td>
                          <td>H-9</td>
                          <td>
                            <button
                              type="button"
                              class="btn btn-secondary btn-sm"
                              disabled
                            >
                              예매취소
                            </button>
                          </td>
                          <td>기간만료</td>
                        </tr>
                      </tbody>
                    </table>
                    <br />
                    <!-- Accordion -->
                    <div
                      class="accordion accordion-flush"
                      id="accordionFlushExample"
                    >
                      <div class="accordion-item">
                        <h2 class="accordion-header">
                          <button
                            class="accordion-button collapsed"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#flush-collapseOne"
                            style="background-color: rgb(207, 226, 255)"
                          >
                            이용안내
                          </button>
                        </h2>
                        <div
                          id="flush-collapseOne"
                          class="accordion-collapse collapse"
                        >
                          <div class="accordion-body">
                            <ul>
                              <p style="font-weight: bold">[예매 안내]</p>
                              <li>
                                만 4세(48개월) 이상부터는 영화티켓을 반드시
                                구매하셔야 입장 가능합니다.
                              </li>
                              <li>
                                예매 변경은 불가능하며, 취소 후 재 예매를
                                하셔야만 합니다.
                              </li>
                              <li>
                                ITN 모바일앱을 이용할 경우 티켓출력없이
                                모바일티켓을 통해 바로 입장하실 수 있습니다.
                              </li>
                              <br />
                              <p style="font-weight: bold">[예매취소 안내]</p>
                              <li>
                                온라인(홈페이지/모바일) 예매 취소는 상영시간
                                20분전까지 입니다.
                              </li>
                              <li>
                                위탁 예매 사이트 이용 시 취소 및 환불 규정은
                                해당 사이트 규정을 따릅니다.
                              </li>
                              <li>
                                공연 관람시 시작 시간 이후에는 입장이 제한
                                됩니다.
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- 구매 내역 -->
                  <div
                    class="tab-pane fade"
                    id="nav-profile"
                    role="tabpanel"
                    aria-labelledby="nav-profile-tab"
                    tabindex="0"
                  >
                    <table
                      class="table table-striped"
                      style="background-color: white"
                    >
                      <br />
                      <thead>
                        <tr class="table-primary">
                          <th scope="col">걸제일시</th>
                          <th scope="col">영화관</th>
                          <th scope="col">상품명</th>
                          <th scope="col">결제금액</th>
                          <th scope="col">환불</th>
                          <th scope="col">상태</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">2024-01</th>
                          <td>동래</td>
                          <td>팝콘</td>
                          <td>6000원</td>
                          <td>
                            <button
                              type="button"
                              class="btn btn-primary btn-sm"
                            >
                              구매취소
                            </button>
                          </td>
                          <td>결제완료</td>
                        </tr>
                        <tr>
                          <th scope="row">2024-01</th>
                          <td>동래</td>
                          <td>제로 콜라</td>
                          <td>2500원</td>
                          <td>
                            <button
                              type="button"
                              class="btn btn-primary btn-sm"
                            >
                              구매취소
                            </button>
                          </td>
                          <td>결제완료</td>
                        </tr>
                        <tr>
                          <th scope="row">2024-01</th>
                          <td>동래</td>
                          <td>콜라</td>
                          <td>2500원</td>
                          <td>
                            <button
                              type="button"
                              class="btn btn-primary btn-sm"
                            >
                              구매취소
                            </button>
                          </td>
                          <td>결제완료</td>
                        </tr>
                      </tbody>
                    </table>

                    <br />
                    <!-- Accordion -->
                    <div
                      class="accordion accordion-flush"
                      id="accordionFlushExample"
                    >
                      <div class="accordion-item">
                        <h2 class="accordion-header">
                          <button
                            class="accordion-button collapsed"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#flush-collapseOne"
                            style="background-color: rgb(207, 226, 255)"
                          >
                            이용안내
                          </button>
                        </h2>
                        <div
                          id="flush-collapseOne"
                          class="accordion-collapse collapse"
                        >
                          <div class="accordion-body">
                            <ul>
                              <p style="font-weight: bold">
                                [스토어 구매/취소 안내]
                              </p>
                              <li>
                                스토어 상품은 구매 후 취소가능기간 내 100%
                                환불이 가능하며, 부분환불은 불가 합니다.
                              </li>
                              <li>
                                (ex. 3개의 쿠폰을 한 번에 구매하신 경우, 3개
                                모두 취소만 가능하며 그 중 사용하신 쿠폰이 있는
                                경우 환불이 불가합니다)
                              </li>
                              <li>
                                스토어 교환권은 MMS로 최대 1회 재전송 하실 수
                                있습니다.
                              </li>
                              <br />
                              <p style="font-weight: bold">
                                [모바일오더 구매/취소 안내]
                              </p>
                              <li>
                                관람권으로 예매 시 차액은 환급되지 않습니다.
                              </li>
                              <li>관람권별 사용정책이 다를 수 있습니다.</li>
                              <li>
                                관람권 사용 시 멤버십 포인트가 적립됩니다.
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- 환불 내역 -->
              <div class="tab-pane fade" id="list-refund" role="tabpanel">
                <p style="font-size: 30px; color: black">환불 내역</p>

                <div class="tab-content" id="nav-tabContent">
                  <!-- 예매 내역 -->
                  <div
                    class="tab-pane fade show active"
                    id="nav-home"
                    role="tabpanel"
                    aria-labelledby="nav-home-tab"
                    tabindex="0"
                  >
                    <table class="table table-striped" style="background-color: white" id="refundTable">
  <br />
  <thead>
    <tr class="table-primary">
      <th scope="col">결제일시</th>
      <th scope="col">영화관</th>
      <th scope="col">구분</th>
      <th scope="col">상품명</th>
      <th scope="col">결제금액</th>
      <th scope="col">상태</th>
    </tr>
  </thead>
  <tbody>
    <!-- 새로운 환불 내역은 이곳에 추가됩니다 -->
  </tbody>
</table>
                    <br />
                  </div>
                </div>
              </div>
              <!-- Movie Ticket Tab -->
              <div class="tab-pane fade" id="list-ticket" role="tabpanel">
                <p style="font-size: 30px; color: black">영화 관람권</p>
                <table class="table" style="background-color: white">
                  <thead>
                    <tr class="table-primary">
                      <th scope="col">관람권명</th>
                      <th scope="col">유효기간</th>
                      <th scope="col">사용상태</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td colspan="3">조회된 관람권이 없습니다.</td>
                    </tr>
                  </tbody>
                </table>

                <!-- Accordion -->
                <div
                  class="accordion accordion-flush"
                  id="accordionFlushExample"
                >
                  <div class="accordion-item">
                    <h2 class="accordion-header">
                      <button
                        class="accordion-button collapsed"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#flush-collapseOne"
                        style="background-color: rgb(207, 226, 255)"
                      >
                        이용안내
                      </button>
                    </h2>
                    <div
                      id="flush-collapseOne"
                      class="accordion-collapse collapse"
                    >
                      <div class="accordion-body">
                        <ul>
                          <li>
                            등록된 관람권은 홈페이지/모바일 예매 시 사용
                            가능하며, 현장 사용은 불가합니다.
                          </li>
                          <li>
                            예매 후 취소 시 유효기간 내 재사용 가능합니다.
                          </li>
                          <li>유효기간 만료 시 사용이 불가합니다.</li>
                          <li>관람권으로 예매 시 차액은 환급되지 않습니다.</li>
                          <li>관람권별 사용정책이 다를 수 있습니다.</li>
                          <li>관람권 사용 시 멤버십 포인트가 적립됩니다.</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- QnA Tab -->
              <div class="tab-pane fade" id="list-qna" role="tabpanel">
                <p style="font-size: 30px; color: black">문의 내역</p>
                <table
                  class="table table-striped"
                  style="background-color: white"
                >
                  <thead>
                    <tr class="table-primary">
                      <th scope="col">번호</th>
                      <th scope="col">제목</th>
                      <th scope="col">답변상태</th>
                      <th scope="col">등록일</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th scope="row">1</th>
                      <td>
                        <button
                          class="accordion-button collapsed"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapseQnA"
                          aria-expanded="false"
                          aria-controls="flush-collapseQnA"
                        >
                          환불관련 문의
                        </button>
                      </td>
                      <td>답변완료</td>
                      <td>2024-01</td>
                    </tr>
                    <tr>
                      <td colspan="4">
                        <div
                          id="flush-collapseQnA"
                          class="accordion-collapse collapse"
                        >
                          <div class="accordion-body">
                            답변: 환불 안해줄거임.
                          </div>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <!-- Member Info Tab -->
              <div class="tab-pane fade" id="list-information" role="tabpanel">
                <p style="font-size: 30px; color: black">회원정보</p>
                <div class="form-floating" id="password-section">
                  <input
                    type="password"
                    class="form-control"
                    id="floatingPassword"
                    placeholder="Password"
                    style="width: 300px"
                  />
                  <label for="floatingPassword" style="color: black"
                    >비밀번호를 입력해 주세요.</label
                  >
                  <button
			      onclick="checkPassword()"
			      style="margin-top: 10px; background-color: #007bff; color: white; border: none; padding: 5px 10px; cursor: pointer;">
			      확인
			    </button>
                </div>
                
                <div id="info-section" style="display: none;">
                <p></p>
			     <table class="table">
  <thead>
    <tr>
      <th scope="col">정보수정</th>
      <th scope="col">email</th>
      <th scope="col">password</th>
      <th scope="col">phone</th>
      <th scope="col">grade</th>
    </tr>
  </thead>
  <tbody>
   <c:forEach var="data" items="${mypages}">
        <tr>
<!--               자동완성 : ctrl + space  -->
         <td>
            <a href="javascript:fn_select
            ('<c:out value="${data.password}" />')">
               <!-- Button trigger modal -->
<button type="button" class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal">
  수정하기
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">회원 정보 수정하기</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="container">
          <!--          부서번호 -->
                 <input type="hidden" name="email" value="<c:out value="${mypageVO.password}" />">
                  
                  <div class="mb-3">
                      <%--             내용 입력양식 --%>
                      <label for="email" class="form-label">이메일 : </label>
                      <input 
                             class="form-control"
                             id="email"
                             name="email"
                             value="<c:out value="${mypageVO.email}" />"
                             placeholder="${data.email}" />
                  </div>
                  
                  <div class="mb-3">
                      <%--            내용 입력양식 --%>
                      <label for="password" class="form-label">비밀번호 : </label>
                      <input 
                             class="form-control"
                             id="password"
                             name="password"
                             value="<c:out value="${mypageVO.password}" />"
                             placeholder="${data.password}" />
                  </div>
                  
                  <div class="mb-3">
                      <%--            내용 입력양식 --%>
                      <label for="phone" class="form-label">전화번호 : </label>
                      <input 
                             class="form-control"
                             id="phone"
                             name="phone"
                             value="<c:out value="${mypageVO.phone}" />"
                             placeholder="${data.phone}" />
                  </div>
                  
                  <div class="mb-3">
                      <%--            내용 입력양식 --%>
                      <label for="grade" class="form-label">등급 : </label>
                      <input 
                             class="form-control"
                             id="grade"
                             name="grade"
                             value="<c:out value="${mypageVO.grade}" />"
                             placeholder="${data.grade}" />
                  </div>
          
                  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">취소</button>
        <button type="button" class="btn btn-info" onclick="fn_save()">저장</button>
      </div>
    </div>
  </div>
</div>
            </a>
         </td>
         <td><c:out value="${data.email}" /></td>
         <td><c:out value="${data.password}" /></td>
         <td><c:out value="${data.phone}" /></td>
         <td><c:out value="${data.grade}" /></td>
       </tr>
   </c:forEach>

  </tbody>
</table>
			    
			    
			    
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
	
    <!-- mypage end -->
    <jsp:include page="/common/footer.jsp"></jsp:include>
  </body>
</html>