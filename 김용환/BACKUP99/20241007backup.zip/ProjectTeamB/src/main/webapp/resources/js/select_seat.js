// 좌석 ID 배열 정의
const seatsToHide = {
    '1': ['A2', 'A7', 'B2', 'B7', 'C2', 'C7', 'D2', 'D7', 'E1', 'E2', 'E3', 'E4', 'E5', 'E6', 'E7', 'E8'],
    '2': ['A2', 'A7', 'B2', 'B7', 'C2', 'C7', 'D1', 'D2', 'D7', 'D8', 'E1', 'E2', 'E3', 'E4', 'E5', 'E6', 'E7', 'E8', 'F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8'],
    '3': ['A1', 'A2', 'A7', 'A8', 'B1', 'B2', 'B7', 'B8', 'C1', 'C2', 'C7', 'C8', 'D1', 'D2', 'D3', 'D4', 'D5', 'D6', 'D7', 'D8']
};

// URL 파라미터에서 관 번호 가져오기
const urlParams = new URLSearchParams(window.location.search);
const theater = urlParams.get('theater'); // 관 번호 (1관, 2관, 3관)

// 해당 관에 따라 좌석 숨기기
if (seatsToHide[theater]) {
    const hiddenSeats = seatsToHide[theater];
    hiddenSeats.forEach(function(seat) {
        const seatButton = document.getElementById(seat);
        if (seatButton) {
            seatButton.style.visibility = 'hidden'; // 좌석 숨기기
        }
    });
}

// 인원 수 초기화
let totalCount = 0; // 총 인원 수
const maxCount = 8; // 최대 인원 수 (예: 8명)

// 각 그룹의 인원 수 초기화
let adultCount = 0;
let youthCount = 0;
let childCount = 0;
let seniorCount = 0;

// 총 인원 수 업데이트 함수
function updateTotalCount() {
    totalCount = adultCount + youthCount + childCount + seniorCount;
}

// 각 그룹의 인원 수 업데이트 함수
function updateCount(group, currentCount, operation) {
    if (operation === 'increase') {
        if (totalCount < maxCount) { // 최대 인원 수 초과 방지
            return currentCount + 1;
        }
    } else if (operation === 'decrease') {
        if (currentCount > 0) { // 최소 인원 수 0 방지
            return currentCount - 1;
        }
    }
    return currentCount; // 변경 없을 경우 기존 값 반환
}

// 각 버튼 클릭 시 이벤트 처리
document.getElementById("adult-minus").onclick = function() {
    adultCount = updateCount("adult", adultCount, 'decrease');
    updateTotalCount();
    document.getElementById("adult-zero").innerText = adultCount;
};

document.getElementById("adult-plus").onclick = function() {
    adultCount = updateCount("adult", adultCount, 'increase');
    updateTotalCount();
    document.getElementById("adult-zero").innerText = adultCount;
};

document.getElementById("youth-minus").onclick = function() {
    youthCount = updateCount("youth", youthCount, 'decrease');
    updateTotalCount();
    document.getElementById("youth-zero").innerText = youthCount;
};

document.getElementById("youth-plus").onclick = function() {
    youthCount = updateCount("youth", youthCount, 'increase');
    updateTotalCount();
    document.getElementById("youth-zero").innerText = youthCount;
};

document.getElementById("child-minus").onclick = function() {
    childCount = updateCount("child", childCount, 'decrease');
    updateTotalCount();
    document.getElementById("child-zero").innerText = childCount;
};

document.getElementById("child-plus").onclick = function() {
    childCount = updateCount("child", childCount, 'increase');
    updateTotalCount();
    document.getElementById("child-zero").innerText = childCount;
};

document.getElementById("senior-minus").onclick = function() {
    seniorCount = updateCount("senior", seniorCount, 'decrease');
    updateTotalCount();
    document.getElementById("senior-zero").innerText = seniorCount;
};

document.getElementById("senior-plus").onclick = function() {
    seniorCount = updateCount("senior", seniorCount, 'increase');
    updateTotalCount();
    document.getElementById("senior-zero").innerText = seniorCount;
};

// 초기 상태 설정
document.getElementById("adult-zero").innerText = adultCount;
document.getElementById("youth-zero").innerText = youthCount;
document.getElementById("child-zero").innerText = childCount;
document.getElementById("senior-zero").innerText = seniorCount;

let selectedSeats = []; // 선택한 좌석 ID를 저장할 배열

// 좌석 클릭 이벤트 추가
document.querySelectorAll('.btn-outline-success').forEach(seat => {
    seat.onclick = function () {
        const seatId = this.id; // 선택된 좌석의 ID (예: A1, B3 등)
        console.log(seatId);

        // 이미 선택된 좌석인 경우
        if (selectedSeats.includes(seatId)) {
            // 선택 해제
            selectedSeats = selectedSeats.filter(seat => seat !== seatId);
            this.classList.remove('selected'); // 선택 해제 스타일 제거

            // 선택 해제 시 select-button-X의 텍스트와 스타일을 초기화
            const selectButtonIndex = selectedSeats.length + 1; // 현재 선택된 좌석 수에 따라 버튼 인덱스 결정
            const selectButton = document.getElementById(`select-button-${selectButtonIndex}`);
            selectButton.textContent = '-'; // 버튼 텍스트를 "-"로 변경
            selectButton.style.backgroundColor = ''; // 배경색 초기화
            selectButton.style.color = ''; // 글자색 초기화
        } else {
            // 선택되지 않은 좌석인 경우
            if (selectedSeats.length < totalCount) { // 총 인원 수에 따라 선택 제한
                selectedSeats.push(seatId);
                this.classList.add('selected'); // 선택 스타일 추가

                // 선택된 좌석을 select-button-X에 표시
                const selectButtonIndex = selectedSeats.length; // 현재 선택된 좌석 수에 따라 버튼 인덱스 결정
                const selectButton = document.getElementById(`select-button-${selectButtonIndex}`);
                
                // 버튼 텍스트를 좌석 ID로 변경하고 스타일 적용
                selectButton.textContent = seatId; // 버튼 텍스트를 좌석 ID로 변경
                selectButton.style.backgroundColor = 'black'; // 배경색을 검정으로 설정
                selectButton.style.color = 'white'; // 글자색을 흰색으로 설정
            } else {
                alert(`선택할 수 있는 좌석 수는 ${totalCount}개 입니다.`);
            }
        }
    };
});

// 리셋 버튼 클릭 시 초기화 기능
document.querySelector('.reset').onclick = function() {
    // 인원 수 초기화
    totalCount = 0; // 총 인원 수 초기화
    adultCount = 0;
    youthCount = 0;
    childCount = 0;
    seniorCount = 0;

    // 인원 수 표시 업데이트
    document.getElementById("adult-zero").innerText = adultCount;
    document.getElementById("youth-zero").innerText = youthCount;
    document.getElementById("child-zero").innerText = childCount;
    document.getElementById("senior-zero").innerText = seniorCount;

    // 선택된 좌석 초기화
    selectedSeats = []; // 선택된 좌석 ID 배열 초기화
    clearSelectedSeatButtons(); // 선택 버튼 초기화
};

// 선택 버튼의 상태를 초기화하는 함수
function clearSelectedSeatButtons() {
    for (let i = 1; i <= maxCount; i++) { // 최대 인원 수 만큼 반복
        const selectButton = document.getElementById(`select-button-${i}`);
        if (selectButton) {
            selectButton.textContent = '-'; // 버튼 텍스트를 "-"로 변경
            selectButton.style.backgroundColor = ''; // 배경색 초기화
            selectButton.style.color = ''; // 글자색 초기화
        }
    }

    // 선택된 좌석 스타일 초기화
    document.querySelectorAll('.btn-outline-success.selected').forEach(seat => {
        seat.classList.remove('selected'); // 선택 해제 스타일 제거
    });
}
