package com.itn.projectb.service.basic;

import java.util.List;

public interface LocationService {
	public List<?> selectLocationList(); 
}
