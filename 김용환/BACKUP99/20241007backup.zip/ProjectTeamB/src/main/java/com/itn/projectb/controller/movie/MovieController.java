package com.itn.projectb.controller.movie;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.core.tools.picocli.CommandLine.Parameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.itn.projectb.service.movie.ReserveService;
import com.itn.projectb.vo.movie.CinemaVO;
import com.itn.projectb.vo.movie.ReserveVO;
import com.itn.projectb.vo.movie.ScreeningVO;

@Controller
public class MovieController {
    @Autowired
    ReserveService reserveService;

    
    @GetMapping("/reserve/choice")
    public String reservechoice(@RequestParam(defaultValue = "") String title,
    		Model model) {
        // 전체 영화 목록을 가져와서 모델에 추가
    	model.addAttribute("title",title);
        return "movie/reserve"; // JSP 페이지로 이동
    }
    
    
    
    
 // 영화 예매 페이지
    @GetMapping("/reserve")
    public String reserve(Model model) {
        // 전체 영화 목록을 가져와서 모델에 추가

        return "movie/reserve"; // JSP 페이지로 이동
    }

    // 선택한 날짜에 맞는 영화 리스트 가져오기
    @GetMapping(value = "/movie/getMoviesByDate", produces = "application/json")
    @ResponseBody
    public List<ScreeningVO> getMoviesByDate(@RequestParam("date") String date) {
        return reserveService.getMoviesByDate(date);
    }   


    @GetMapping("/movie/getScreeningInfo")
    @ResponseBody
    public List<ScreeningVO> getScreeningInfo(@RequestParam String movie,
                                               @RequestParam String city,
                                               @RequestParam String branch,
                                               @RequestParam String date) {
        Map<String, Object> params = new HashMap<>();
        params.put("movie", movie);
        params.put("city", city);
        params.put("branch", branch);
        params.put("date", date);

        return reserveService.getScreeningInfo(params);
    }
    
    
    

    @GetMapping("/reserve/select1") // 경로를 지정합니다.
    public String select(Model model) {        
        return "movie/select_seat"; // JSP 페이지로 이동
    }
    
    
    
}

