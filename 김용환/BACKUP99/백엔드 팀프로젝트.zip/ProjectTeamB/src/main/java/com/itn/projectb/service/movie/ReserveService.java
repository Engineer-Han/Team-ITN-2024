/**
 * 
 */
package com.itn.projectb.service.movie;

import java.util.List;

import com.itn.projectb.vo.movie.ReserveVO;

/**
  * @fileName : ReserveService.java
  * @author : KTE
  * @since : 2024. 9. 27. 
  * description :
  */

public interface ReserveService {

	 List<ReserveVO> selectMovieTitles(); // 영화 제목 조회 메서드
	 List<ReserveVO> selectTheaterAreas();
}
