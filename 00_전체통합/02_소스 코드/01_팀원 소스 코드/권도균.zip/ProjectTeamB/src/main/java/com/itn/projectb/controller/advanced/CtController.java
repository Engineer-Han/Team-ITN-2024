package com.itn.projectb.controller.advanced;

import java.util.ArrayList;
import java.util.List;



import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springmodules.validation.commons.DefaultBeanValidator;

import com.itn.projectb.service.advanced.Ct4Service;
import com.itn.projectb.service.advanced.CtService;
import com.itn.projectb.vo.Member.MemberVO;
import com.itn.projectb.vo.advanced.Ct4VO;
import com.itn.projectb.vo.advanced.CtVO;
import com.itn.projectb.vo.common.Criteria;

import lombok.experimental.PackagePrivate;
import lombok.extern.log4j.Log4j;

@Log4j
@Controller

public class CtController {
	
	
	@Autowired
	   private CtService ctService;
	
	@Autowired
	private Ct4Service ct4Service;
	
	   
	

	
//	@GetMapping("/oneonone")
//	   public String oneononeView() {
//	      return "oneonone/oneonone";
//	   }                                                    
//	
//	

	
	
	
//	@GetMapping("/gongji")
//	   public String gongjiView() {
//	      return "gongji/gongji";  //공지페이지
//	   }                                
//	
		/*
		 * @GetMapping("/oneononeas") public String oneononeasView() { return
		 * "oneononeas/oneononeas"; //1:1 상세페이지 }
		 */                   
	
//	@GetMapping("/often")
//	   public String oftenView() {
//	      return "often/often";  // 자주묻는 질문 상세페이지
//	   }                                
//	
	
//	@GetMapping("/oftenas")
//	   public String oftenasView() {
//	      return "oftenas/oftenas";  // 자주묻는 질문 상세페이지
//	   }                                
//	
//	@GetMapping("/gongjias")
//	   public String gongjiasView() {
//	      return "gongjias/gongjias";  //공지 상세페이지
//	   }                                
//	
	
	
	
	@PostMapping("/oneonone/write") // insert 실행 - post방식
	   public String createCt(@ModelAttribute CtVO ctVO, HttpSession session,  RedirectAttributes redirectAttributes, @RequestParam(defaultValue = " ") String inid
) throws Exception { 
		  
		
//	      System.out.println("테스트 " + deptVO);
//	      사용법 : log.info(변수);
//	      log.info("테스트 " + ctVO);
//	      1) 서비스의 함수 실행 : insert 함수
//		ctVO.setWriter("joonbyungsuh@naver.com");
		log.info("CT VO: " + ctVO);
	       MemberVO memberVO = (MemberVO) session.getAttribute("memberVO");
	       if (memberVO == null) {
	           redirectAttributes.addFlashAttribute("errorMessage", "로그인이 필요합니다.");
	           return "redirect:/login";
	       }
	       ctVO.setWriter(memberVO.getEmail());
	      ctService.insertCt(ctVO);
		  
		
	      return "redirect:/oneonone";  // 2) 전제조회 페이지로 강제이동
	   }
 
	
	
	
	//글쓰기 저장 --> 셀렉트 함수 만들어서 리스트를 뿌려줘야된다 
	@GetMapping("/oneonone")
	public String selectCtList(@RequestParam(required = false) String inid,
	                            @ModelAttribute("searchVO") Criteria searchVO,
	                            Model model) throws Exception {

	    // 데이터 조회를 위한 페이징 설정
	    searchVO.setPageUnit(3);
	    searchVO.setPageSize(5);
	    
	    PaginationInfo paginationInfo = new PaginationInfo();
	    paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
	    paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
	    paginationInfo.setPageSize(searchVO.getPageSize());

	    // 페이징 정보 저장
	    searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
	    searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
	    searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

	    // CT4 리스트 조회
	    List<?> ct4List = ct4Service.selectCt4List(searchVO);
	    model.addAttribute("ct4List", ct4List);
	  

	    // CT 리스트 조회
	    List<?> ctList = ctService.selectCtList(searchVO);
	    model.addAttribute("ctList", ctList);

	    // 전체 개수 조회 및 페이지 정보 저장
	    int totCnt = ctService.selectCtListTotCnt(searchVO);
	    paginationInfo.setTotalRecordCount(totCnt);
	    model.addAttribute("paginationInfo", paginationInfo);

	    // 'inid'가 null이 아닐 경우 해당 값을 모델에 추가
	    if (inid != null) {
	        model.addAttribute("inid", inid);
	    }

	    return "oneonone/oneonone"; // JSP 페이지 반환
	}

	   
	   
	   
	   @PostMapping("/oneonone/delete")
	   public String deleteCt(@ModelAttribute CtVO ctVO) throws Exception {
		   System.out.println("아아아아아아아아아"); 
//	      1) deptSerive 의 delete 함수 실행
		   ctService.deleteCt(ctVO);
	      return "redirect:/oneonone"; // 2) 전체조회로 강제이동
	   }
	   
	   
	   
	   
	   
	   
	   // 상세조회 페이지 열기
	    @GetMapping("/oneononeas")
	    public String oneononeDetail(@RequestParam("inid") String inid, Model model) throws Exception {
	        // 1) ctService의 상세조회 함수 실행
	        CtVO ctvo = ctService.selectCt(inid);
	        Ct4VO ct4vo =ctService.selectAn(inid);
	        // 2) 모델에 담아 JSP로 전송
	        model.addAttribute("ctvo", ctvo);
	        model.addAttribute("ct4vo", ct4vo);
	        
	        // 3) 상세 조회 페이지로 이동
	        return "oneononeas/oneononeas";  // This should be the path to your detailed JSP view
	        
	
	    
	    }
	    
	        
	    
	   
	   
	//   수정 버튼 클릭시 수정하는 함수 : update 실행(dno, DeptVO)
	//   jsp : 
//	   @PostMapping("/oneononech")
//	   public String updateCt(@RequestParam String inid,
//	                     @ModelAttribute CtVO ctVO
//	         ) throws Exception {
////	        1) deptService 의 update 함수 실행
//	      ctService.updateCt(ctVO);
////	        2) 전체조회로 강제이동
//	      return "redirect:/oneonone"; // 전체조회로 강제이동
//	   }
//	   
//	    
	 

		@PostMapping("/oneononech") // update 실행 - post방식
		   public String updateCt(@ModelAttribute CtVO ctVO, HttpSession session,  RedirectAttributes redirectAttributes, @RequestParam(defaultValue = " ") String inid
	) throws Exception { 
			  
			
//		      System.out.println("테스트 " + deptVO);
//		      사용법 : log.info(변수);
//		      log.info("테스트 " + ctVO);
//		      1) 서비스의 함수 실행 : insert 함수
//			ctVO.setWriter("joonbyungsuh@naver.com");
			log.info("CT VO: " + ctVO);
		       MemberVO memberVO = (MemberVO) session.getAttribute("memberVO");
		       if (memberVO == null) {
		           redirectAttributes.addFlashAttribute("errorMessage", "로그인이 필요합니다.");
		           return "redirect:/login";
		       }
		       ctVO.setWriter(memberVO.getEmail());
		      ctService.insertCt(ctVO);
			  
			
		      return "redirect:/oneonone";  // 2) 전제조회 페이지로 강제이동
		   }
	    
	    
	    
	    
	    
	   
	   
	   
	   
	   @GetMapping("/oneononech")
	   public String updateCtList(
	          @RequestParam("inid") String inid,  // 게시글 ID를 파라미터로 받음
	          Model model) throws Exception {

	       // 1) 게시글 ID로 해당 게시글 데이터 조회
	       CtVO ctVO = ctService.selectCt(inid);

	       // 2) 모델에 게시글 데이터 추가
	       model.addAttribute("ctVO", ctVO);

	       // 3) 수정 페이지로 이동
	       return "oneonone/oneononech";
	   
	   
	   }
	   
	   
	   
	


//	   @GetMapping("/cm")
//public String selectCmList(
//		   @ModelAttribute("searchVO") Criteria searchVO,
//	         Model model) throws Exception {
////	        TODO: 0) 페이징 변수에 설정 : 
//			searchVO.setPageUnit(3); // 1페이지당 화면에 보이는 개수
//			searchVO.setPageSize(5); // 페이지 번호를 보여줄 개수
//
////			TODO: 페이지 객체 생성
//			PaginationInfo paginationInfo = new PaginationInfo(); // 페이징 객체
//			paginationInfo.setCurrentPageNo(searchVO.getPageIndex()); // 현재 페이지 번호 저장
//			paginationInfo.setRecordCountPerPage(searchVO.getPageUnit()); // 1페이지당 보일 게시물 개수
//			paginationInfo.setPageSize(searchVO.getPageSize()); // 페이지 번호를 보여줄 개수
//
////			TODO: searchVO 객체 페이징 정보 저장
//			searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex()); // 첫페이지번호
//			searchVO.setLastIndex(paginationInfo.getLastRecordIndex()); // 끝페이지번호
//			searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage()); // 1페이지당 보일 게시물 개수
//
//			List<?> ctList = ctService.selectCtList(searchVO);
//			model.addAttribute("ctList", ctList);
//			
////			TODO: 3)  Exam 테이블의 총개수(서비스 객체의 함수를 실행) : 페이지 객체 저장
//			int totCnt = ctService.selectCtListTotCnt(searchVO);
//
//			paginationInfo.setTotalRecordCount(totCnt);
////			TODO: 페이징 객체 -> jsp 전달
//			model.addAttribute("paginationInfo", paginationInfo);
//        return "cm/cm";
      
  // }
  
	   
	


//	   @GetMapping("/cmas")
//	   public String showEditForm(@RequestParam("inid") String inid, Model model) throws Exception {
//	       // Fetch the inquiry data using the provided inid
//	       CtVO ctVO = ctService.selectCt(inid); // Make sure this method is defined to retrieve the inquiry by ID
//	       model.addAttribute("ctVO", ctVO); // Add the inquiry data to the model for the JSP
//	       return "cm/cmas"; // inid를 관리자 페이지 수정폼으로 데이터 날림
//	   }
//	   
  

	   
	
//	   @GetMapping("/cm")
//	   public String updateCtList2(
// 	      @RequestParam("inid") String inid,  // 게시글 ID를 파라미터로 받음
//          Model model) throws Exception {
//
//     // 1) 게시글 ID로 해당 게시글 데이터 조회
//	       CtVO ctVO = ctService.selectCt(inid);
//
//      // 2) 모델에 게시글 데이터 추가
//	       model.addAttribute("ctVO", ctVO);
//
//      // 3) 수정 페이지로 이동
//       return "oneonone/oneonone";
//
//	
//	   
//	   }
//	   
//	   
	   
	   
//	   @GetMapping("/cm")
//	   public String update5CtList(
//	           @RequestParam("inid") String inid,  // 게시글 ID를 파라미터로 받음
//	           Model model) throws Exception {
//
//	       // 1) 게시글 ID로 해당 게시글 데이터 조회
//	       CtVO ctVO = ctService.selectCt(inid);
//
//	       // 2) 모델에 게시글 데이터 추가
//	       model.addAttribute("ctVO", ctVO);
//
//	       // 3) 수정 페이지로 이동
//	       return "cm/cm"; // 수정 페이지로 이동
//	   }
//	   
//	   

	   
//	   
//		@GetMapping("/cm")
//	   public String cmView() {
//	      return "cm/cm";
//	   }                                                    
//	
//	   
	   
	   
	   
	   
	   
	   
	   
}


	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
