package com.itn.projectb.service.impl.basic;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itn.projectb.mapper.basic.CompanyAboutMapper;
import com.itn.projectb.service.basic.CompanyAboutService;

@Service
public class CompanyAboutServiceImpl implements CompanyAboutService{
	
	@Autowired
	CompanyAboutMapper companyAboutMapper;

	@Override
	public List<?> selectCompanyAboutList() {
		// TODO Auto-generated method stub
		return companyAboutMapper.selectCompanyAboutList();
	}

	

}
