const listView = document.getElementById("listView");

listView.addEventListener("click",()=>{
	location.href = ContextPath + "/exam";
});