function noticePage(){
	location.href = ContextPath + "/noticeAll";
}

function faqPage(){
	location.href =  ContextPath + "/faqList";
}

function InquiryPage(){
	location.href =  ContextPath + "/inquiryList";
}