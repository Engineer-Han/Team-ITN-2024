package com.itn.projectb.mapper.auth;

import org.apache.ibatis.annotations.Mapper;

import com.itn.projectb.vo.Member.MemberVO;

@Mapper
public interface MemberMapper {
	public MemberVO authenticate(MemberVO memberVO);
	public void register(MemberVO memberVO);
	

}
