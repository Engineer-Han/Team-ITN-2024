package com.itn.projectb.vo.movie;

public class CinemaVO {
	private String ccid;
    private String cinema;
    private String branch;
    private int theater; 
    private int seats;    
    private String city;
    private String address;
    private String imageUrl;
    private String insertTime;
    private String updateTime;
    
    
    
    //getter,setter
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	} 	
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}

}
