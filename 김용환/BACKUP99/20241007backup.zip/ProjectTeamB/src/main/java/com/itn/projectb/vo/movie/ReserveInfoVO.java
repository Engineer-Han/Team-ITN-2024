package com.itn.projectb.vo.movie;

public class ReserveInfoVO {
    private String movieTitle;
    private String theaterArea;
    private String theaterTitle;
    private String runningDate; // 상영 날짜
    private String startTime;    // 상영 시작 시간
    private String endTime;      // 상영 종료 시간

    // 기본 생성자
    public ReserveInfoVO() {}

    // 모든 필드를 포함하는 생성자
    public ReserveInfoVO(String movieTitle, String theaterArea, String theaterTitle, String runningDate, String startTime, String endTime) {
        this.movieTitle = movieTitle;
        this.theaterArea = theaterArea;
        this.theaterTitle = theaterTitle;
        this.runningDate = runningDate;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    // Getter 및 Setter 메서드
    public String getMovieTitle() { return movieTitle; }
    public void setMovieTitle(String movieTitle) { this.movieTitle = movieTitle; }

    public String getTheaterArea() { return theaterArea; }
    public void setTheaterArea(String theaterArea) { this.theaterArea = theaterArea; }

    public String getTheaterTitle() { return theaterTitle; }
    public void setTheaterTitle(String theaterTitle) { this.theaterTitle = theaterTitle; }

    public String getRunningDate() { return runningDate; }
    public void setRunningDate(String runningDate) { this.runningDate = runningDate; }

    public String getStartTime() { return startTime; }
    public void setStartTime(String startTime) { this.startTime = startTime; }

    public String getEndTime() { return endTime; }
    public void setEndTime(String endTime) { this.endTime = endTime; }
}
