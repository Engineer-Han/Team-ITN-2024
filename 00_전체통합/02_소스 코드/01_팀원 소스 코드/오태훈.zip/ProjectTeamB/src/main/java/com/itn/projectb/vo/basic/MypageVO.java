/**
 * 
 */
package com.itn.projectb.vo.basic;


import com.itn.projectb.vo.common.Criteria;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
  * @fileName : MypageVO.java
  * @author : KTE
  * @since : 2024. 9. 26. 
  * description :
  */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@SuppressWarnings("serial")
public class MypageVO extends Criteria{
	private String email, password, phone, grade, insertTime;
	
	private String boid, title, bookNum, customer, selectSeat, scid, updateTime;
	private	int selectNum, childrenNum, teenagerNum, adultNum, agedNum;
	
	private String paid, methodType;
	private int totalPrice ;
}
