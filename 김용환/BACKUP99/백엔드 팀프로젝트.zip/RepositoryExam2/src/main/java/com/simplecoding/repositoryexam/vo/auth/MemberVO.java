/**
 * 
 */
package com.simplecoding.repositoryexam.vo.auth;

import org.springframework.web.multipart.MultipartFile;

import com.simplecoding.repositoryexam.vo.common.Criteria;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
  * @fileName : MemberVO.java
  * @author : KTE
  * @since : 2024. 9. 19. 
  * description :
  */

//EMAIL	VARCHAR2(1000 BYTE)
//PASSWORD	VARCHAR2(1000 BYTE)
//NAME	VARCHAR2(1000 BYTE)
//INSERT_TIME	VARCHAR2(255 BYTE)
//UPDATE_TIME	VARCHAR2(255 BYTE) -- >  2개 Critera에 있어서 상속
@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuppressWarnings("serial")
public class MemberVO extends Criteria{
	
	private String email; //기본키
	private String password; 
	private String name; 
	
	
}
