package com.itn.projectb.service.impl.qna;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itn.projectb.mapper.qna.QnaMapper;
import com.itn.projectb.service.qna.QnaService;
import com.itn.projectb.vo.common.Criteria;
import com.itn.projectb.vo.qna.QnaVO;

@Service
public class QnaServiceImpl implements QnaService{
	@Autowired
	private QnaMapper qnaMapper;

	@Override
	public List<?> selectQnaList(Criteria searchVO) throws Exception {
		// TODO Auto-generated method stub
		return qnaMapper.selectQnaList(searchVO);
	}

	@Override
	public int selectQnaListTotCnt(Criteria searchVO) {
		// TODO Auto-generated method stub
		return qnaMapper.selectQnaListTotCnt(searchVO);
	}

	@Override
	public QnaVO selectQna(String faid) throws Exception {
		QnaVO qnaVO = qnaMapper.selectQna(faid);
		return qnaVO;
	}

	@Override
	public void updateQnaVO(QnaVO qnaVO) throws Exception {
		qnaMapper.update(qnaVO);
		
	}

	@Override
	public void deleteQnaVO(QnaVO qnaVO) throws Exception {
		qnaMapper.delete(qnaVO);
	}

	@Override
	public void insertQna(QnaVO qnaVO) throws Exception {
		qnaMapper.insert(qnaVO);
	}

	
}
