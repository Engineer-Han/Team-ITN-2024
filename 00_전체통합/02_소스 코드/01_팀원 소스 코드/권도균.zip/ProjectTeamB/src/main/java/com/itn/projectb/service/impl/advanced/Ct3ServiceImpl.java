package com.itn.projectb.service.impl.advanced;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itn.projectb.mapper.advanced.Ct3Mapper;
import com.itn.projectb.service.advanced.Ct3Service;
import com.itn.projectb.vo.advanced.Ct3VO;
import com.itn.projectb.vo.common.Criteria;

@Service
public class Ct3ServiceImpl implements Ct3Service {

	
	
	@Autowired
	Ct3Mapper ct3Mapper;
	
	
	
	
	@Override
	public List<?> selectCt3List(Criteria searchVO) throws Exception {
		// TODO Auto-generated method stub
		return ct3Mapper.selectCt3List(searchVO);
	}

	@Override
	public int selectCt3ListTotCnt(Criteria searchVO) {
		// TODO Auto-generated method stub
		return ct3Mapper.selectCt3ListTotCnt(searchVO);
	}

	@Override
	public Ct3VO selectCt3(String noid) throws Exception {
		// TODO Auto-generated method stub
		Ct3VO ct3vo = ct3Mapper.selectCt3(noid);
		return ct3vo;
	}

	
	
	
	
	
	
	
	
	
}
