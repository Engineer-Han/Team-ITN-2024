package com.itn.projectb.service.impl.movie;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.itn.projectb.mapper.movie.ReserveMapper;
import com.itn.projectb.service.movie.ReserveService;
import com.itn.projectb.vo.movie.CinemaVO;
import com.itn.projectb.vo.movie.ReserveVO;
import com.itn.projectb.vo.movie.ScreeningVO;

@Service
public class ReserveServiceImpl implements ReserveService {
    @Autowired
    ReserveMapper reserveMapper;

    
//    극장지역 
    @Override
    public List<ScreeningVO> getMoviesByDate(String date) {
        return reserveMapper.getMoviesByDate(date);
    }

    @Override
    public List<ScreeningVO> getScreeningInfo(Map<String, Object> params) {
        return reserveMapper.getScreeningInfo(params);
    }
    
    
}
