/**
 * 
 */
package com.itn.projectb.mapper.basic;



import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.itn.projectb.vo.basic.MypageVO;
import com.simplecoding.repositoryexam.vo.common.Criteria;




/**
  * @fileName : MypageMapper.java
  * @author : KTE
  * @since : 2024. 9. 26. 
  * description :
  */
@Mapper
@Repository
public interface MypageMapper {
	public List<?> selectMypageList(Criteria seachVO);
	public MypageVO authenticate(MypageVO mypageVO); // 회원정보 열람
	public MypageVO selectMypage(String password);
	public int update(MypageVO mypageVO);
	public List<?> selectStoreList(Criteria searchVO);
		
	
}
