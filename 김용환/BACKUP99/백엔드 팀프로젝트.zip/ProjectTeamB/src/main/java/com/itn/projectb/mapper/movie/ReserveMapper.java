package com.itn.projectb.mapper.movie;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.itn.projectb.vo.movie.ReserveVO;

@Mapper
public interface ReserveMapper {
    List<ReserveVO> selectMovieTitles(); // 영화 제목만 조회하는 메서드
    List<ReserveVO> selectTheaterAreas();// 극장 위치만 조회하는 메서드
}