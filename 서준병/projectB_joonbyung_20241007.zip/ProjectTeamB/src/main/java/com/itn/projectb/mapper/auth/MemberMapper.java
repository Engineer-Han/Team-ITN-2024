package com.itn.projectb.mapper.auth;

import org.apache.ibatis.annotations.Mapper;

import com.itn.projectb.vo.Member.MemberVO;

@Mapper
public interface MemberMapper {
	public MemberVO authenticate(MemberVO memberVO); //로그인 인증
	public void register(MemberVO memberVO); // 회원가입
	public int checkEmail(MemberVO memberVO); // 이메일 중복 체크


}
