/**
 * 
 */
package com.itn.projectb.service.basic;

import java.util.List;

import org.springframework.stereotype.Service;

import com.itn.projectb.vo.basic.MypageVO;
import com.simplecoding.repositoryexam.vo.common.Criteria;


/**
  * @fileName : MypageService.java
  * @author : KTE
  * @since : 2024. 9. 26. 
  * description :
  */
@Service
public interface MypageService {
	public List<?> selectMypageList(Criteria seachVO) throws Exception;
	
	public MypageVO authenticateMypage(MypageVO loginVO) throws Exception;
	MypageVO selectMypage(String password) throws Exception;
	void updateMypage(MypageVO mypageVO) throws Exception;
	public List<?> selectStoreList(Criteria searchVO) throws Exception;
}
