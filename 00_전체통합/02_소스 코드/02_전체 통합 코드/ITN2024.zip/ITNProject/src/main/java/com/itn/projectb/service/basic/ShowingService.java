package com.itn.projectb.service.basic;

import com.itn.projectb.vo.basic.ShowingVO;

public interface ShowingService {
	public void createShowing(ShowingVO showingVO);
}
