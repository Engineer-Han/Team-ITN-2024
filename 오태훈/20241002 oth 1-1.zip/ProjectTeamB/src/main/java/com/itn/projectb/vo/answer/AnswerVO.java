package com.itn.projectb.vo.answer;

import com.itn.projectb.vo.common.Criteria;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class AnswerVO  extends Criteria{

	private String anid, contents, inid, writer, insert_time, update_time;

}
