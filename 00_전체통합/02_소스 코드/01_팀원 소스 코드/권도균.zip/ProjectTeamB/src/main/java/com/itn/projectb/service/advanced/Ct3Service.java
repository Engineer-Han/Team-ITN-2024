package com.itn.projectb.service.advanced;

import java.util.List;

import com.itn.projectb.vo.advanced.Ct3VO;
import com.itn.projectb.vo.common.Criteria;

public interface Ct3Service {




	public List<?> selectCt3List(Criteria searchVO)  throws Exception; // 전체조회 함수
	public int selectCt3ListTotCnt(Criteria searchVO); // 페이징
	 Ct3VO selectCt3(String noid) throws Exception; // 상세보기


	
	
	
	
	
	
	
	
}
