package com.itn.projectb.mapper.basic;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ExamMapper {
	public List<?> selectExamList();
}
