/**
 * 
 */
package com.itn.projectb.vo.basic;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
  * @fileName : MypageVO.java
  * @author : KTE
  * @since : 2024. 9. 26. 
  * description :
  */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class MypageVO {
	private String email, password, phone, grade, insertTime, updateTime;
}
