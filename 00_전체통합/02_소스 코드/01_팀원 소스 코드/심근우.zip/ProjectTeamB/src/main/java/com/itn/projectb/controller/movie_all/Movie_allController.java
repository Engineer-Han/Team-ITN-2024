package com.itn.projectb.controller.movie_all;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.itn.projectb.service.movie_all.Movie_allService;
import com.itn.projectb.vo.Member.MemberVO;
import com.itn.projectb.vo.common.Criteria;
import com.itn.projectb.vo.movie_all.Movie_allVO;
import com.itn.projectb.vo.movie_all.Movie_reviewVO;

import lombok.extern.log4j.Log4j;

@Log4j
@Controller
public class Movie_allController {
   
   @Autowired
   Movie_allService movie_allService;
   

   
//   전체 조회 함수
   @GetMapping("/movie_all")
   public String selectMovie_allList(
         @ModelAttribute("searchVO") Criteria searchVO,
         Model model) throws Exception {
   
//   TODO: 0) 페이징 변수에 설정 : 
   searchVO.setPageUnit(12); // 1페이지당 화면에 보이는 개수
   searchVO.setPageSize(2); // 페이지 번호를 보여줄 개수
   
//   TODO: 페이지 객체 생성
   PaginationInfo paginationInfo = new PaginationInfo();         // 페이징 객체
   paginationInfo.setCurrentPageNo(searchVO.getPageIndex());     // 현재 페이지 번호 저장
   paginationInfo.setRecordCountPerPage(searchVO.getPageUnit()); // 1페이지당 보일 게시물 개수
   paginationInfo.setPageSize(searchVO.getPageSize());           // 페이지 번호를 보여줄 개수
   
//   TODO: searchVO 객체 페이징 정보 저장
   searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());           // 첫페이지번호
   searchVO.setLastIndex(paginationInfo.getLastRecordIndex());             // 끝페이지번호
   searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage()); // 1페이지당 보일 게시물 개수

   
   
//   1) 서비스 객체의 함수를 실행 : deptService.전체조회()
   List<?> movie_alls = movie_allService.selectMovie_allList(searchVO);
//   2) 모델에 결과(depts) 담아 jsp 전송
   model.addAttribute("movie_alls", movie_alls);
   
//   TODO: 3) 부서 테이블의 총개수(서비스 객체의 함수를 실행) : 페이지 객체 저장
   int totCnt = movie_allService.selectMovie_allListTotCnt(searchVO);
   paginationInfo.setTotalRecordCount(totCnt);
//   TODO: 페이징 객체 -> jsp 전달
   model.addAttribute("paginationInfo", paginationInfo);
   
   return "movie_all/movie_all";
}



   public Movie_allController(Movie_allService movie_allService) {
      super();
      this.movie_allService = movie_allService;
   }



//   상세조회 페이지 열기 :
   @GetMapping("/view_details")
   public String updateMovie_allView(@RequestParam(defaultValue = "") String pdid, Model model) 
               throws Exception {
      
//      1) deptService 의 상세조회 함수 실행 
      System.out.println(pdid);
      Movie_allVO movie_allVO = movie_allService.selectMovie_all(pdid);
      
//      2) 모델에 담아 Jsp 로 전송
      model.addAttribute("movie_allVO", movie_allVO);
      
      List<?> reviewsVIEW = movie_allService.selectMovie_reviews(pdid);
      
//      2) 모델에 결과(depts) 담아 jsp 전송
      model.addAttribute("reviewsVIEW", reviewsVIEW);
      
//      log.info("테스트"+movie_allVO);
      return "view_details/view_details";
   }
   
//   관람평 등록
   @PostMapping("/view_details_review_register")
   public String review_register (@ModelAttribute Movie_allVO movie_allVO, 
                               @RequestParam(defaultValue = "") String pdid, 
                               @RequestParam String review, 
                               HttpSession session, 
                               Model model,
                               RedirectAttributes redirectAttributes) throws Exception {

       // 세션에서 로그인한 사용자 정보 가져오기 (작성자 정보)
       MemberVO memberVO = (MemberVO) session.getAttribute("memberVO");
       if (memberVO == null) {
           redirectAttributes.addFlashAttribute("errorMessage", "로그인이 필요합니다.");
           return "redirect:/login";
       }

       // PDID를 이용해 영화 정보를 가져오기
       Movie_allVO movie_allVO1 = movie_allService.selectMovie_all(pdid);
              

       // 리뷰 및 작성자 정보 설정
       movie_allVO1.setReview(review);  // 리뷰 내용 설정
       movie_allVO1.setWriter(memberVO.getEmail());  // 작성자 정보 설정 (세션에서 가져옴)

       model.addAttribute("movie_allVO", movie_allVO1);
       try {
           // 리뷰 등록 호출
           movie_allService.review_register(movie_allVO1); 
           redirectAttributes.addFlashAttribute("successMessage", "리뷰가 성공적으로 등록되었습니다.");
       } catch (Exception e) {
           redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
           String encodedPdid = URLEncoder.encode(movie_allVO1.getPdid(), StandardCharsets.UTF_8.toString());
           return "redirect:/view_details?pdid=" + encodedPdid;  // 오류 발생 시 리다이렉트
       }

       // 성공 시 상세보기 페이지로 리다이렉트
       String encodedPdid = URLEncoder.encode(movie_allVO1.getPdid(), StandardCharsets.UTF_8.toString());
       return "redirect:/view_details?pdid=" + encodedPdid;
   }
   
////   관람평 조회
//   @GetMapping("/view_details_review_view")
//   public String selectMovie_reviewsList(
//         @ModelAttribute("searchVO") Criteria searchVO,         
//         Model model) throws Exception {
//      
////      TODO: 0) 페이징 변수에 설정 : 
//      searchVO.setPageUnit(3); // 1페이지당 화면에 보이는 개수
//      searchVO.setPageSize(2); // 페이지 번호를 보여줄 개수
//      
////      TODO: 페이지 객체 생성
//      PaginationInfo paginationInfo = new PaginationInfo();         // 페이징 객체
//      paginationInfo.setCurrentPageNo(searchVO.getPageIndex());     // 현재 페이지 번호 저장
//      paginationInfo.setRecordCountPerPage(searchVO.getPageUnit()); // 1페이지당 보일 게시물 개수
//      paginationInfo.setPageSize(searchVO.getPageSize());           // 페이지 번호를 보여줄 개수
//      
////      TODO: searchVO 객체 페이징 정보 저장
//      searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());           // 첫페이지번호
//      searchVO.setLastIndex(paginationInfo.getLastRecordIndex());             // 끝페이지번호
//      searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage()); // 1페이지당 보일 게시물 개수
//      
////      1) 서비스 객체의 함수를 실행 : deptService.전체조회()
//      List<?> reviewsVIEW = movie_allService.selectMovie_reviews(searchVO);
//      log.info ("테스트" + reviewsVIEW);
////      2) 모델에 결과(depts) 담아 jsp 전송
//      model.addAttribute("reviewsVIEW", reviewsVIEW);
//      
////      TODO: 3) 부서 테이블의 총개수(서비스 객체의 함수를 실행) : 페이지 객체 저장
//      int totCnt = movie_allService.selectMovie_reviewsTotCnt(searchVO);
//      paginationInfo.setTotalRecordCount(totCnt);
////      TODO: 페이징 객체 -> jsp 전달
//      model.addAttribute("paginationInfo", paginationInfo);
//      
//      
//      return "view_details/view_details";
//   }

   


}
   
   
