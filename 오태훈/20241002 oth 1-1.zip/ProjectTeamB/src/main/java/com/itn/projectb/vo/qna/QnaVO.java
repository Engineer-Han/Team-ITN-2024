package com.itn.projectb.vo.qna;

import com.itn.projectb.vo.common.Criteria;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class QnaVO  extends Criteria{

	private String faid, title, contents, writer, update_time, insert_time;

}
