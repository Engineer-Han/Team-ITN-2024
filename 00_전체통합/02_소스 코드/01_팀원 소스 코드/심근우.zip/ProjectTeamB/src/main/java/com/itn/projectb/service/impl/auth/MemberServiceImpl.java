package com.itn.projectb.service.impl.auth;

import org.apache.ibatis.jdbc.SQL;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibatis.sqlmap.engine.mapping.sql.Sql;
import com.itn.projectb.mapper.auth.MemberMapper;
import com.itn.projectb.service.auth.MemberService;
import com.itn.projectb.vo.Member.MemberVO;

@Service

public class MemberServiceImpl implements MemberService {
	// 인증 : 상세조회
	@Autowired
	MemberMapper memberMapper;

	@Override
	public MemberVO authenticateMember(MemberVO loginVO) throws Exception {

		MemberVO memberVO = memberMapper.authenticate(loginVO);

		if (memberVO != null) {
			boolean isMatchedPassword = BCrypt.checkpw(loginVO.getPassword(), memberVO.getPassword());
			if (isMatchedPassword == false) {
				throw new Exception("비밀번호가 틀렸습니다.");
			}
		}

		return memberVO;

	}

	// register(insert) : source
	@Override
	public void registerMember(MemberVO memberVO) throws Exception {
		String hashedPassword = BCrypt.hashpw(memberVO.getPassword(), BCrypt.gensalt());
		memberVO.setPassword(hashedPassword);
		memberMapper.register(memberVO);
	}

	// 아이디 중복 확인
	@Override
	public boolean checkEmailDuplicate(MemberVO memberVO) throws Exception {		
		int count = memberMapper.checkEmail(memberVO);
		return count > 0;
	}


	

	
	
}
