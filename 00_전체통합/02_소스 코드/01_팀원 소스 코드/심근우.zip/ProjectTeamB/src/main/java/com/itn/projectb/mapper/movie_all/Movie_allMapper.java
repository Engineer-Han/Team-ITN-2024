package com.itn.projectb.mapper.movie_all;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.itn.projectb.vo.movie_all.Movie_allVO;
import com.itn.projectb.vo.common.Criteria;

@Mapper
public interface Movie_allMapper {
	public List<?> selectMovie_allList();
	public List<?> selectMovie_allList(Criteria searchVO);   // 전체 조회 : 페이징 기능 추가
	public int selectMovie_allListTotCnt(Criteria searchVO); // 개수 세기 
	public int insert(Movie_allVO movie_allVO);                   // insert 함수
	public Movie_allVO selectMovie_all(String pdid);                  // 상세조회 함수
	public void review_register(Movie_allVO movie_allVO); // 영화 실관람평 리뷰 등록

	public int selectProductCount(String title);// 영화 실관람평 리뷰 등록
	
	public List<?> selectMovie_reviews(String pdid); // 관람평 전체 조회 : 페이징 기능 추가
	public int selectMovie_reviewsTotCnt(Criteria search_reaviewsVO); // 관람평 개수 세기
}
