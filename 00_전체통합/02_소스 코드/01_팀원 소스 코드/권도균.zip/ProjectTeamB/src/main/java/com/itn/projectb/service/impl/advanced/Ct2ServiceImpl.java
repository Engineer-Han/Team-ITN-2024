package com.itn.projectb.service.impl.advanced;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itn.projectb.mapper.advanced.Ct2Mapper;
import com.itn.projectb.service.advanced.Ct2Service;
import com.itn.projectb.vo.advanced.Ct2VO;
import com.itn.projectb.vo.common.Criteria;


@Service
public class Ct2ServiceImpl implements Ct2Service {

	@Autowired
	Ct2Mapper ct2Mapper;


	@Override
	public List<?> selectCt2List(Criteria searchVO) throws Exception {
		// TODO Auto-generated method stub
		return ct2Mapper.selectCt2List(searchVO);
                 //전체조회 검색
	}

	@Override
	public int selectCt2ListTotCnt(Criteria searchVO) {
		// TODO Auto-generated method stub
		return ct2Mapper.selectCt2ListTotCnt(searchVO);
	}                // 페이징

	@Override
	public Ct2VO selectCt2(String faid) throws Exception {
		// TODO Auto-generated method stub
		Ct2VO ct2vo = ct2Mapper.selectCt2(faid);
		
		return ct2vo;
	}        //상세보기


	

	
	
	
	

}
