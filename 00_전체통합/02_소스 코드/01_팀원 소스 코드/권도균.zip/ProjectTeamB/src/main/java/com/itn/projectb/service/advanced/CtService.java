package com.itn.projectb.service.advanced;

import java.util.List;

import com.itn.projectb.vo.advanced.Ct4VO;
import com.itn.projectb.vo.advanced.CtVO;
import com.itn.projectb.vo.common.Criteria;

public interface CtService {

	void insertCt(CtVO ctVO) throws Exception; // insert 함수
	public List<?> selectCtList(Criteria searchVO)  throws Exception; // 전체조회 함수
	public int selectCtListTotCnt(Criteria searchVO); // 페이징
	public void deleteCt(CtVO ctVO) throws Exception; //삭제
	public  CtVO selectCt(String inid) throws Exception; // 상세보기
	public Ct4VO selectAn(String inid);
	public void updateCt(CtVO ctVO) throws Exception; // 수정 함수
}
