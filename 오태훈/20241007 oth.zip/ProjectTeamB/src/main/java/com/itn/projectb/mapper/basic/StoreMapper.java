package com.itn.projectb.mapper.basic;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.itn.projectb.vo.basic.StoreVO;
import com.simplecoding.repositoryexam.vo.common.Criteria;

@Mapper
public interface StoreMapper {
	public List<?> selectStoreList(Criteria searchVO);
	public int insert(StoreVO storeVO);
}
