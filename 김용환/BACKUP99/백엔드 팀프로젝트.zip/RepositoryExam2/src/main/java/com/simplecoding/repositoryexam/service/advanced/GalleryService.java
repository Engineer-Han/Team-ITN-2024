/**
 * 
 */
package com.simplecoding.repositoryexam.service.advanced;

import java.util.List;

import com.simplecoding.repositoryexam.vo.common.Criteria;

/**
  * @fileName : GalleryService.java
  * @author : KTE
  * @since : 2024. 9. 12. 
  * description :
  */

//연습) 전체조회 함수 : selectGalleryList
//*                    자식클래스(GalleryServiceImpl 에 함수재정의 코딩)
//*                    컨트롤러(GalleryService 의 selectGalleryList 실행)

public interface GalleryService {
	 List<?>selectGalleryList(Criteria searchVO);
	 int selectGalleryListTotCnt(Criteria searchVO);
}
