package com.itn.projectb.mapper.answer;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.itn.projectb.vo.common.Criteria;
import com.itn.projectb.vo.qna.QnaVO;


@Mapper
public interface AnswerMapper {
	public List<?> selectAnswerList(Criteria searchVO);
	public int selectAnswerListTotCnt(Criteria searchVO);
//	public int insert(QnaVO qnaVO); 						// insert 함수
//	public QnaVO selectQna(String faid);						// 상세조회함수
//	public int update(AnswerVO answerVO); 						// update함수 
//	public int delete(QnaVO qnaVO);
}
