package com.itn.projectb.vo.movie;



public class ReserveVO {

}


