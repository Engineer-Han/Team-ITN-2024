package com.itn.projectb.vo.Member;

import com.itn.projectb.vo.common.Criteria;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@SuppressWarnings("serial")

public class MemberVO extends Criteria {
	private String email;
	private String email1;
	private String email2;
	private String password;
	private String phone;
}
