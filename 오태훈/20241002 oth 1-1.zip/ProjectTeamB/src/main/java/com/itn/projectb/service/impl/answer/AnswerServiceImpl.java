package com.itn.projectb.service.impl.answer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itn.projectb.mapper.answer.AnswerMapper;
import com.itn.projectb.mapper.qna.QnaMapper;
import com.itn.projectb.service.answer.AnswerService;
import com.itn.projectb.service.qna.QnaService;
import com.itn.projectb.vo.common.Criteria;
import com.itn.projectb.vo.qna.QnaVO;

@Service
public class AnswerServiceImpl implements AnswerService{
	@Autowired
	private AnswerMapper answerMapper;

	@Override
	public List<?> selectQnaList(Criteria searchVO) throws Exception {
		return answerMapper.selectAnswerList(searchVO);
	}

	@Override
	public int selectQnaListTotCnt(Criteria searchVO) {
		return answerMapper.selectAnswerListTotCnt(searchVO);
	}



//	@Override
//	public QnaVO selectQna(String faid) throws Exception {
//		QnaVO qnaVO = qnaMapper.selectQna(faid);
//		return qnaVO;
//	}

//	@Override
//	public void updateQnaVO(QnaVO qnaVO) throws Exception {
//		qnaMapper.update(qnaVO);
//		
//	}
//
//	@Override
//	public void deleteQnaVO(QnaVO qnaVO) throws Exception {
//		qnaMapper.delete(qnaVO);
//	}
//
//	@Override
//	public void insertQna(QnaVO qnaVO) throws Exception {
//		qnaMapper.insert(qnaVO);
//	}

	
}
